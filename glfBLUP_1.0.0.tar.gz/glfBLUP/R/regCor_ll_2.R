#' regCor_ll_2
#'
#' \code{regCor_ll_2} calculates the negative log-likelihood assuming an identity
#' matrix regularization target.
#'
#' @param penalty The regularization penalty value.
#' @param R.eigenvalues Eigenvalues of R (see \code{precalcVecs})
#' @param A.diag Diagonal elements of A (see \code{precalcVecs})
#'
#' @returns The negative log-likelihood
#' @keywords internal
#'
regCor_ll_2 <- function(penalty, R.eigenvalues, A.diag) {

  ll <- log(prod((1 - penalty) * R.eigenvalues + penalty)) + sum(A.diag / ((1 - penalty) * R.eigenvalues + penalty))
  return(ll)

}

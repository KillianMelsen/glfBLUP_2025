#' vec.inv.diag
#'
#' \code{vec.inv.diag} directly computes the traces of lambda_1^x and lambda_2^x.
#'
#' @param x A numeric vector
#' @param y A numeric vector
#'
#' @return A matrix containing the traces of lambda_1^x and lambda_2^x.
#'
#' @keywords internal
vec.inv.diag <- function(x,y) {

  p <- length(x)
  n <- length(y)
  z <- sapply(x,function(x_i){return(1 / (rep(1,n) + x_i * y))})
  return(z)
}

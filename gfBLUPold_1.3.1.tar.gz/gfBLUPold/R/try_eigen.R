#' try_eigen
#'
#' @param X A covariance matrix
#'
#' @keywords internal
#'
try_eigen <- function(X) {
  tryCatch(
    return(eigen(X)), error = function(e) {
      cat("ERROR: ", e$message, ", acting as if the matrix is not PD...\n\n", sep = "")
      return(list(values = -1))
    }
  )
}

#' Genetic factor best linear unbiased prediction
#'
#' \code{gfBLUP2} makes multi-trait genomic predictions using a factor-analytic dimension reduction
#' of the secondary traits.
#'
#' @param d A dataframe containing the genotype, a set of secondary traits, and a focal trait. Must contain replicates.
#'
#' @param K The kinship matrix of training and test genotypes.
#'
#' @param geno An optional argument specifying the column containing the genotypes. The default assumes the first column
#' of \code{d} contains the genotypes.
#'
#' @param focal An optional argument specifying the column containing the focal trait. The default assumes the last column
#' of \code{d} contains the focal trait.
#'
#' @param sec An optional argument specifying the column indices of the columns in \code{d} that contain the secondary traits.
#' The default assumes all columns of \code{d} except the first and last contain the secondary traits.
#'
#' @param t.RF Threshold value for redundancy filtering. Defaults to \code{0.95}.
#'
#' @param reg.target Argument specifying the regularization target to be used. Default is \code{"identity"} which uses the
#' identity matrix. Passing a user-specified correlation matrix to be used as the target is also possible.
#'
#' @param reg.penalty Optional argument in case a user-specified regularization penalty must be used
#' (must be a positive number and at most 1). If left at default value of NULL the optimal penalty will
#' be determined using 5-fold CV. If specifying a penalty, this CV process is skipped.
#'
#' @param low Lower bound for the unique variances.
#'
#' @param subset.select The subset selection method. \code{subset.select = c("leaps","CV")}.
#'
#' @param CV.percentile The top percentage of subsets that should be evaluated using cross validation for the \code{"CV"}
#' subset selection method. Only specify either \code{CV.percentile} or \code{CV.number}.
#'
#' @param CV.number The top \code{n} subsets that should be evaluated using cross validation for the \code{"CV"}
#' subset selection method. Only specify either \code{CV.percentile} or \code{CV.number}.
#'
#' @param sepExp Boolean that must be set to TRUE if the focal trait was measured
#' in a different experiment/on different plants than the secondary traits. If that is the case,
#' the residual covariances between the focal trait and factors will be set to 0.
#'
#' @param do.parallel Boolean specifying whether to use paralellization or not.
#'
#' @param max.cores Maximum number of cores to be used for the paralellization. NULL by default,
#' which results in \code{n - 2} cores being used. Can be useful if using too many
#' cores with large datasets results in memory issues.
#'
#' @param verbose Display information or not.
#'
#' @return A list containing:
#' * A named numeric vector containing the test set predictions.
#' * The optimal regularization penalty.
#' * A character vector containing the names of the selected factors.
#' * The loadings matrix.
#' * The uniqueness matrix.
#' * The number of factors used based on the Marchenko-Pastur bound and eigenvalues of the regularized genetic correlation matrix.
#' * The KMO score.
#' * The genetic covariance matrix of factors and the focal trait.
#' * The residual covariance matrix of factors and the focal trait.
#' * A numeric vector containing the heritabilities of factors and the focal trait.
#' * The direct selection accuracy measure. Only returned if \code{subset.select = "CV"}.
#' * The indirect selection accuracy measures for each subset. Only returned if \code{subset.select = "CV"}.
#'
#' @examples
#' ## Import the included example dataset:
#' example <- gfBLUPold::simExampleData
#'
#' ## Run gfBLUP:
#' results <- gfBLUP2(d = example$d, K = example$K, subset.select = "leaps")
#'
#' ## Calculate prediction accuracy:
#' cor(results$preds, example$pred.target)
#'
#' @importFrom stats aggregate cor cov2cor na.omit optim
#'
#' @export
#'

gfBLUP2.DEV <- function(d, K, geno = NULL, focal = NULL, sec = NULL,
                        t.RF = 0.95, reg.target = "identity", reg.penalty = NULL, low = 0.1,
                        subset.select = "leaps", CV.percentile = NULL, CV.number = NULL,
                        sepExp = FALSE, do.parallel = FALSE,  max.cores = NULL, verbose = TRUE) {

  # 1. Argument checking =======================================================
  tictoc::tic("Total", quiet = TRUE) # Total running time (except the return statement...)

  stopifnot(class(d) == "data.frame",
            class(K) == c("matrix", "array"),
            class(geno) %in% c("character", "NULL"),
            class(focal) %in% c("character", "NULL"),
            class(sec) %in% c("integer", "numeric", "NULL"),
            class(t.RF) == "numeric",
            t.RF > 0 & t.RF <= 1,
            ifelse(class(reg.target) == "character",
                   reg.target == "identity",
                   class(reg.target) == c("matrix", "array") &
                     isSymmetric(reg.target) &
                     all(diag(reg.target) == 1)),
            subset.select %in% c("CV", "leaps"),
            class(low) == "numeric",
            class(verbose) == "logical",
            class(do.parallel) == "logical",
            class(max.cores) %in% c("numeric", "NULL"))

  # 2. Preliminary things ======================================================

  # Storing names of genotype and focal trait colnames, as well as indices for secondary traits:
  if (is.null(geno)) {geno <- names(d)[1]}
  if (is.null(focal)) {focal <- names(d)[ncol(d)]}
  if (is.null(sec)) {sec <- 2:(length(names(d)) - 1)}

  # Reformatting input data so it only includes genotype, secondary traits, and the
  # focal trait in the order geno-sec-focal:
  d <- cbind(d[, geno], d[, sec], d[, focal])

  # Changing the genotype and focal trait column names of d for easy referencing:
  names(d)[1] <- "G"
  names(d)[ncol(d)] <- "Y"

  # Determining training and test set:
  train.set <- as.character(unique(d$G[!is.na(d$Y)]))
  test.set <- as.character(setdiff(unique(d$G), train.set))

  # Determining CV scenario:
  if (all(is.na(d[which(d$G %in% test.set), 2:(ncol(d) - 1)]))) {
    CV <- "CV1"
  } else if (!any(is.na(d[which(d$G %in% test.set), 2:(ncol(d) - 1)]))) {
    CV <- "CV2"
  } else {
    stop("Either all secondary traits must be present for the test set, or missing...")
  }

  # Changing genotype to a factor and dropping any levels if necessary:
  d$G <- as.factor(d$G)
  d <- droplevels(d)

  # 3. Redundancy filtering ====================================================
  if (verbose) {cat("Starting redundancy filtering...\n")}

  tictoc::tic("Redundancy filtering", quiet = TRUE) # Redundancy filtering

  # Estimating genetic covariance matrix of secondary traits for redundancy filtering:
  if (CV == "CV1") {
    Vg.all.sec <- covFromSS2(data = d[, 1:(ncol(d) - 1)], use_nearPD = FALSE)$Vg
  } else if (CV == "CV2") {
    Vg.all.sec <- covFromSS2(data = d[which(d$G %in% train.set), 1:(ncol(d) - 1)], use_nearPD = FALSE)$Vg
  }

  # Redundancy filtering the genetic correlation matrix of secondary traits:
  Rg.filter.sec <- FMradio::RF(cov2cor(Vg.all.sec), t = t.RF)

  if (verbose) {
    cat(sprintf("%d out of %d secondary traits remain after redundancy filtering...\n\n",
                dim(Rg.filter.sec)[1], dim(Vg.all.sec)[1]))
  }

  # Subsetting data after redundancy filtering:
  d <- cbind(d$G, as.data.frame(FMradio::subSet(as.matrix(d[, 2:(ncol(d) - 1)]), Rg.filter.sec)), d$Y)
  names(d)[1] <- "G"
  names(d)[ncol(d)] <- "Y"

  tictoc::toc(log = TRUE) # Redundancy filtering

  # Adding back genotype and focal trait:
  # d.subset <- as.data.frame(cbind(d$G, d.subset, d[, focal]))
  # names(d.subset)[1] <- "G"
  # names(d.subset)[ncol(d.subset)] <- focal

  # Removing rows with missing data (test genotypes) for regularization:
  d.train <- na.omit(d)
  d.train <- droplevels(d.train)

  # Subsetting user specified regularization target (if specified):
  if (class(reg.target)[1] == "matrix") {
    remove <- rownames(reg.target)[!(rownames(reg.target) %in% rownames(Rg.filter.sec))]
    reg.target <- reg.target[setdiff(rownames(reg.target), remove), setdiff(colnames(reg.target), remove)]
  }

  # 4. Regularization ==========================================================

  # Regularizing the genetic correlation matrix of remaining secondary traits:
  if (verbose) {
    cat("Regularizing genetic correlation matrix of remaining secondary traits ")
    if (class(reg.target)[1] == "matrix") {
      cat("using user-specified regularization target...\n")
    } else {
      cat("using identity regularization target...\n")
    }
  }

  tictoc::tic("Regularization", quiet = TRUE) # Regularization

  OPT <- regGenCor2(X = d.train[, -ncol(d.train)], fold = 5,
                    targetmatrix = reg.target, verbose = verbose,
                    do.parallel = do.parallel, reg.penalty = reg.penalty)

  tictoc::toc(log = TRUE) # Regularization

  if (verbose) {cat(sprintf("Optimal penalty value set at %g...\n\n", OPT$optPen))}

  KMO <- FMradio::SA(OPT$optCor)

  if (verbose) {cat(sprintf("KMO measure of %g...\n", KMO$KMO))}

  # 5. Fitting factor model and obtaining scores ===============================

  # Calculating Marchenko-Pastur bound for the number of factors to be used:
  MP.bound <- (1 + sqrt(ncol(OPT$optCor) / length(train.set)))^2

  # Factor number determination (if not specified):
  m <- sum(eigen(OPT$optCor)$values > MP.bound)

  if (verbose) {
    cat(sprintf("M-P bound is %g...\n", MP.bound))
    cat(sprintf("Fitting factor model with %d factors...\n", m))
  }

  tictoc::tic("Fitting factor model", quiet = TRUE) # Fitting factor model

  # Fitting factor model:
  fit <- mlFA2(R = OPT$optCor, m = m, low = low)

  tictoc::toc(log = TRUE) # Fitting factor model

  # Preparing dataframe for factor scores:
  # d.fact <- data.frame(matrix(numeric(), nrow(d), m))
  # names(d.fact) <- paste0("F", 1:m)

  tictoc::tic("Determining factor scores", quiet = TRUE) # Determining factor scores

  # Creating factor score dataframe:
  # Note that in CV2 the factor model was fit using only the training set, but here factor scores
  # are calculated for the test set as well (Because the secondary traits were never set to
  # NA for the test set).
  d.fact <- FMradio::facScore(as.matrix(d[, colnames(OPT$optCor)]), fit$Loadings, fit$Uniqueness)
  d.fact <- cbind(d$G, d.fact, d$Y)
  factors <- paste0("F", 1:m)
  names(d.fact) <- c("G", factors, "Y")

  tictoc::toc(log = TRUE) # Determining factor scores

  # 6. Preparing for subset selection and BLUP calculations ====================

  # Creating final dataframe with arithmetic means:
  dm <- genoMeans(data = d.fact)
  dm$G <- as.character(dm$G)
  dm <- dm[match(c(test.set, train.set), dm$G),]
  rownames(dm) <- c(test.set, train.set)

  # Calculating Vg and Ve to be used in subset selection and BLUP calculations:
  # Again, in CV2 Vg and Ve are calculated using only the training set.
  covmats <- covFromSS2(data = na.omit(d.fact), calc.Ve = TRUE, use_nearPD = TRUE, sepExp = sepExp)

  # Creating vector of factor and focal trait heritabilities:
  H2vec <- diag(covmats$Vg) / (diag(covmats$Vg) + diag(covmats$Ve))

  # Storing names of factors and focal trait:
  t.names  <- names(d.fact)[-1]

  # Determining number of replicates:
  n.rep.vector <- as.integer(table(d.fact$G))
  n.rep <- (sum(n.rep.vector) - sum(n.rep.vector^2) / sum(n.rep.vector)) / (length(n.rep.vector) - 1)

  # 7. Subset selection ========================================================

  tictoc::tic("Subset selection", quiet = TRUE) # Subset selection

  if (verbose) {
    cat(sprintf("Starting subset selection using %s method...\n", subset.select))
    if (subset.select == "CV") {
      cat(sprintf("Evaluating top %d%% of subsets based on accuracy measure...\n", CV.percentile * 100))
    }
  }

  if (subset.select == "leaps") {
    F.select <- subset_leaps(d = na.omit(dm), factors = factors, focal = "Y")
  } else {
    ACCM <- acc_measures(factors = factors, Vg = covmats$Vg, Ve = covmats$Ve,
                         focal = "Y", H2.focal = H2vec[length(H2vec)])

    if (verbose) {
      cat(sprintf("Evaluating top %d subsets out of %d...\n",
                  ceiling(length(ACCM$zxc.scores) * CV.percentile),
                  length(ACCM$zxc.scores)))
    }

    F.select <- subset_CV(d = na.omit(dm), CV.percentile = CV.percentile, div = FALSE,
                          zxc = ACCM$zxc, zxc.scores = ACCM$zxc.scores, focal = "Y",
                          Vg = covmats$Vg, Ve = covmats$Ve, n.rep = n.rep, K = K,
                          do.parallel = do.parallel, CV = CV, max.cores = max.cores)
  }

  if (verbose) {
    cat(sprintf("Selected factors using %s method are %s...\n\n", subset.select, paste(F.select, collapse = ", ")))
  }

  tictoc::toc(log = TRUE) # Subset selection

  # 8. BLUP calculations =======================================================

  # Creating appropriate subsets based on subset selection:
  dm.subset <- dm[, c("G", F.select, "Y")]
  Vg.subset <- covmats$Vg[c(F.select, "Y"), c(F.select, "Y")]
  Ve.subset <- covmats$Ve[c(F.select, "Y"), c(F.select, "Y")]

  if (min(eigen(Vg.subset)$values) < 0) {
    if (verbose) {
      cat("Subsetted genetic covariance matrix is not positive-definite. Using nearPD()...\n")
    }
    Vg.subset <- as.matrix(Matrix::nearPD(x = Vg.subset)$mat)
  }

  if (verbose) {cat("Making final test set predictions...\n")}

  tictoc::tic("BLUP calculations", quiet = TRUE) # BLUP calculations

  if (CV == "CV1") {
    # Calculating BLUPs for the training set:
    BLUPs_train <- fast_o_gBLUP(Y = as.matrix(dm.subset[train.set, -1]),
                                K = K,
                                Vg = Vg.subset,
                                Ve = Ve.subset / n.rep,
                                train.set = train.set,
                                targetName = "Y")

    # Calculating focal trait BLUP for the test set:
    focalBLUP_test <- train2test(BLUPs_train$focal_gBLUP, K = K,
                                 train.set = train.set, test.set = test.set)
  } else if (CV == "CV2") {
    # Using the two-step approach (See pitfalls paper Runcie & Cheng 2019)
    # Calculating BLUPs for the training set:
    BLUPs_train <- fast_o_gBLUP(Y = as.matrix(dm.subset[train.set, -1]),
                                K = K,
                                Vg = Vg.subset,
                                Ve = Ve.subset / n.rep,
                                train.set = train.set,
                                targetName = "Y")

    # Calculating all BLUPs for the test set:
    BLUPs_test <- train2test(BLUPs_train$all_gBLUPs, K = K,
                             train.set = train.set, test.set = test.set)

    BLUP_Y_test <- BLUPs_test[, "Y"]
    BLUP_S_test <- BLUPs_test[, setdiff(colnames(BLUPs_test), "Y")]
    Ktt.inv <- solve(K[test.set, test.set])
    Kto <- K[test.set, train.set]
    Koo <- K[train.set, train.set]
    Vc <- kronecker(Vg.subset[F.select, F.select], Ktt.inv) + kronecker(Ve.subset[F.select, F.select] / n.rep, diag(dim(Ktt.inv)[1]))

    # Final CV2 test set focal trait BLUP calculation following two-step approach (Runcie & Cheng, 2019):
    focalBLUP_test <- as.numeric(matrix(BLUP_Y_test) + kronecker(t(as.matrix(Vg.subset[F.select, "Y"])), Ktt.inv) %*%
                                   solve(Vc) %*% (matrix(as.matrix(dm.subset[test.set, F.select])) - matrix(BLUP_S_test)))

    names(focalBLUP_test) <- test.set
  }

  tictoc::toc(log = TRUE) # BLUP calculations

  tictoc::toc(log = TRUE) # Total time

  if (subset.select == "leaps") {
    return(list(preds = focalBLUP_test,
                regPen = OPT$optPen,
                F.subset = F.select,
                FM.loadings = fit$Loadings,
                FM.uniquenesses = fit$Uniqueness,
                FM.m = m,
                FM.scores = dm,
                KMO = KMO,
                Vg = covmats$Vg,
                Ve = covmats$Ve,
                H2s = H2vec))
  } else if (subset.select == "CV") {
    return(list(preds = focalBLUP_test,
                regPen = OPT$optPen,
                F.subset = F.select,
                FM.loadings = fit$Loadings,
                FM.uniquenesses = fit$Uniqueness,
                FM.m = m,
                FM.scores = dm,
                KMO = KMO,
                Vg = covmats$Vg,
                Ve = covmats$Ve,
                H2s = H2vec,
                AM.direct = as.numeric(ACCM$criterion),
                AM.indirect = ACCM$zxc.scores))
  }
}

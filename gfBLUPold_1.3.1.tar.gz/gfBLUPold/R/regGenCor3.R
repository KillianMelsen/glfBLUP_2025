#' regGenCor
#'
#' Regularizes the genetic covariance matrix of remaining secondary traits.
#'
#' @param X A matrix where the first column contains the genotypes. All other columns must contain
#' secondary trait measurements. Must not contain any NA values, so must only contain training
#' genotypes.
#' @param fold Number of folds to use.
#' @param targetmatrix Character indicating what regularization target to use.
#' Leave on \code{"identity"} for now.
#' @param verbose Boolean indicating whether to display information or not.
#' @param do.parallel Boolean indicating whether to use parallelization or not.
#' @param reg.penalty Optional argument in case a user-specified regularization penalty must be used. If left at default value of NULL
#' the optimal penalty will be determined using 5-fold CV. If specifying a penalty, note that it must be between 0 and 1.
#'
#' @param use.nearPD See gfBLUP3 documentation.
#'
#' @return A list containing the optimal penalty value, the regularized genetic
#' correlation matrix, and a non-regularized RF filtered genetic covariance matrix for
#' easy conversion of optCor back to a covariance matrix.
#'
#' @keywords internal
regGenCor3 <- function(X, fold, targetmatrix = "identity", verbose = FALSE, do.parallel, reg.penalty = NULL, use.nearPD = FALSE) {

  if (!is.data.frame(X)) {
    stop("Input (X) should be a dataframe")
  }
  if (class(fold) != "numeric" & class(fold) != "integer") {
    stop("Input (fold) is of wrong class")
  }
  if (fold <= 1) {
    stop("Input (fold) should be at least 2")
  }
  if (fold > nrow(X)) {
    stop("Input (fold) cannot exceed the sample size")
  }
  if (class(verbose) != "logical") {
    stop("Input (verbose) is of wrong class")
  }
  if (verbose) {
    cat("Determining folds...", "\n")
  }

  # Calculate genotype means:
  mu.geno <- genoMeans(data = X)

  # Determine number of reps:
  n.rep.vector <- as.integer(table(X$G))
  n.rep <- (sum(n.rep.vector) - sum(n.rep.vector^2) / sum(n.rep.vector)) / (length(n.rep.vector) - 1)

  if (is.null(reg.penalty)) {

    # Create folds:
    ngeno <- length(n.rep.vector)
    fold <- max(min(ceiling(fold), ngeno), 2)
    fold <- rep(1:fold, ceiling(ngeno / fold))[1:ngeno]
    shuffle <- sample(unique(X$G), ngeno)
    folds <- split(shuffle, as.factor(fold))
    n.folds <- length(folds)

    if (verbose) {
      cat("Pre-calculating vectors for each fold...\n")
      # size <- ((ncol(X) - 1)^2 * 8 + 216) / 1024^2 * length(folds) * 2
      # cat(sprintf("Expected memory size of %g MB...\n", round(size, 3)))
    }

    if (do.parallel) {
      cores <- min(n.folds, parallel::detectCores() - 2)
      doParallel::registerDoParallel(cores = cores)
      cat(sprintf("Parallelizing the pre-calculation process using %d cores...\n", cores))

      vecs <- foreach::foreach(i = 1:n.folds, .packages = c("gfBLUPold")) %dopar% {
        # Making a dataframe for 4/5 folds:
        R_dataframe <- droplevels(X[!(X$G %in% folds[[i]]), , drop = FALSE])

        # Calculating eigen decomp of R:
        R.ED <- eigen(cov2cor(covFromSS2(data = R_dataframe, mu.geno = mu.geno, n.rep = n.rep, use_nearPD = use.nearPD)$Vg))

        # Making a dataframe for the left out fold:
        S_dataframe <- droplevels(X[X$G %in% folds[[i]], , drop = FALSE])

        # Calculating A:
        A.diag <-  diag(t(R.ED$vectors) %*%
                          cov2cor(covFromSS2(data = S_dataframe, mu.geno = mu.geno, n.rep = n.rep, use_nearPD = use.nearPD)$Vg) %*%
                          R.ED$vectors)

        return(list(R.EV = R.ED$values, A.diag = A.diag, nf = dim(S_dataframe)[1]))
        }
      doParallel::stopImplicitCluster()
    } else if (!do.parallel) {
      vecs <- vector("list", n.folds)
      for (i in 1:n.folds) {
      # Making a dataframe for 4/5 folds:
      R_dataframe <- droplevels(X[!(X$G %in% folds[[i]]), , drop = FALSE])

      # Calculating eigen decomp of R:
      R.ED <- eigen(cov2cor(covFromSS2(data = R_dataframe, mu.geno = mu.geno, n.rep = n.rep, use_nearPD = use.nearPD)$Vg))

      # Making a dataframe for the left out fold:
      S_dataframe <- droplevels(X[X$G %in% folds[[i]], , drop = FALSE])

      # Calculating A:
      A.diag <-  diag(t(R.ED$vectors) %*%
                        cov2cor(covFromSS2(data = S_dataframe, mu.geno = mu.geno, n.rep = n.rep, use_nearPD = use.nearPD)$Vg) %*%
                        R.ED$vectors)

      # Adding both to the list of pre-calculated matrices:
      vecs[[i]] <- list(R.EV = R.ED$values, A.diag = A.diag, nf = dim(S_dataframe)[1])
      }
    }

    if (verbose) {cat("Determining optimal penalty value...\n")}

    optLambda <- optim(0.5, regGenCor_kcvl3, method = "Brent", lower = 0, upper = 1,
                       targetmatrix = targetmatrix, vecs = vecs)$par

  } else {
    optLambda <- reg.penalty
  }

  # Also return genetic covariance matrix of RF data for easy
  # conversion of optCor to covariance matrix:
  # RFsubset_cov <- covFromSS2(data = X, mu.geno = mu.geno,
  #                           n.rep = n.rep, calc.Ve = FALSE, use_nearPD = FALSE)$Vg

  # return(list(optPen = optLambda,
  #             optCor = (1 - optLambda) * cov2cor(RFsubset_cov) + optLambda * diag(dim(RFsubset_cov)[1]),
  #             RFsubset_cov = RFsubset_cov))

  return(list(optPen = optLambda))
}

#' getLambda
#'
#' @param dag dag of class graphNEL
#'
#' @return q
#'
#' @keywords internal
getLambda <- function(dag) {
  # dag is of class graphNEL
  # The output is the same as :
  # as.matrix(get.adjacency(graph_from_graphnel(dag)))
  # except that the latter returns zeros and ones,
  # while the function here returns the edgeweights
  ew     <- graph::edgeWeights(dag)
  vnames <- names(ew)
  p      <- length(vnames)

  Lambda <- matrix(0, p, p)
  colnames(Lambda) <- rownames(Lambda) <- vnames

  for (v in vnames) {
    i <- which(vnames == v)
    if (length(ew[[i]]) > 0) {
      for (w in names(ew[[i]])) {
        j <- which(vnames == w)
        Lambda[i, j] <- ew[[i]][[w]]
      }
    }
  }
  return(Lambda)
}

#' Example simulated dataset
#'
#' This list contains a simulated dataset containing 500 genotypes, three replicates,
#' and observations on 50 secondary traits and one focal trait. The list also includes
#' the relevant kinship matrix, and vectors containing the prediction target, test set
#' genotypes, and training set genotypes. The data was generated using \code{simFactorData()}
#'
#' @format ## `simExampleData`
#' A list containing 5 elements:
#' \describe{
#' \item{d}{A dataframe containing the actual data.}
#' \item{K}{A 500 x 500 kinship matrix of the genotypes in \code{d}.}
#' \item{test.set}{A character vector containing the test set genotypes.}
#' \item{train.set}{A character vector containing the training set genotypes.}
#' \item{pred.target}{A named numeric vector containing the focal trait prediction target values for the test set.}
#' }
"simExampleData"

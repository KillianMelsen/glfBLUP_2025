#' regGenCor_ll
#'
#' A small helper function for regGenCor that calculates the negative log-likelihood.
#'
#' @param S The genetic correlation matrix of the left out fold.
#' @param R The regularized genetic correlation matrix based on the other folds.
#' @param use_ginv Boolean indicating whether to calculate the generalized inverse
#' if R is singular.
#'
#' @return The calculated log-likelihood.
#'
#' @keywords internal
regGenCor_ll <- function(S, R, use_ginv = FALSE) {
  if (use_ginv) {
    ll <- log(det(R)) + sum(S*MASS::ginv(R))
  } else {
    ll <- log(det(R)) + sum(S*solve(R))
  }
  return(ll)
}

#' allSubsets
#'
#' Generate all possible proper subsets for a given number of factors.
#'
#' @param my_vec A vector containing the names of the factors.
#'
#' @return An object containing vectors representing the subsets. Each vector
#' contains the names of the factors in that subset.
#'
#' @keywords internal
allSubsets <- function(my_vec) {

  my_combi1 <- unlist(lapply(1:length(my_vec), combinat::combn, x = my_vec,
                             simplify = FALSE), recursive = FALSE)
  return(my_combi1)
}

#' subset_AC
#'
#' A function that returns the subset of factors with the highest accuracy measure.
#'
#' @param zxc Vector containing the names of all subsets.
#' @param zxc.scores Vector with the accuracy measure scores of all subsets.
#' @param criterion The accuracy criterion as calculated by acc_measure.
#' @param criterion.override Boolean indicating whether to override the criterion if none
#' of the subsets have a high enough accuracy measure.
#' @param verbose Boolean indicating whether to print information or not.
#'
#' @return A character vector with the names of the selected factors.
#'
#' @keywords internal
subset_AC <- function(zxc, zxc.scores, criterion, criterion.override, verbose) {

  if (max(zxc.scores) > criterion | criterion.override) {
    if (max(zxc.scores) < criterion & verbose) {
      cat("Criterion not passed. Overriding...\n")
    }
    F.select <- zxc[[which.max(zxc.scores)]]
    return(F.select)
  } else {
    stop("No subset crossed the AC threshold and criterion.override was set to FALSE!\n\n")
  }
}

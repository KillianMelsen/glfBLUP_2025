#' regGenCor_kcvl
#'
#' A helper function for regGenCor that calculates the mean cross-validated
#' negative log-likelihood that is used to find the optimal penalty.
#'
#' @param penalty The penalty that must me optimized.
#' @param targetmatrix The regularization target as passed from regGenCor.
#' @param do.parallel boolean indicating whether to use parallelization or not.
#' @param mats The list containing the pre-calculated genetic correlation matrices
#' for each fold.
#'
#' @return The mean cross-validated negative log-likelihood.
#'
#' @importFrom foreach %dopar%
#'
#' @keywords internal
regGenCor_kcvl2 <- function(penalty, targetmatrix, do.parallel, mats) {
  n.folds <- length(mats)
  if (!(do.parallel)) {
    cvLL <- 0
    for (i in 1:n.folds){
      cvLL <- cvLL + mats[[i]]$nf * regGenCor_ll(mats[[i]]$S,
                                                 regGenCor_corlw(mats[[i]]$R, penalty, targetmatrix),
                                                 use_ginv = FALSE)
    }
    return(cvLL / n.folds)
  } else if (do.parallel) {
    cvLL <- foreach::foreach(i = 1:n.folds, .combine = "+", .packages = c("gfBLUPold")) %dopar% {
      LL <- mats[[i]]$nf * gfBLUPold:::regGenCor_ll(mats[[i]]$S,
                                                 gfBLUPold:::regGenCor_corlw(mats[[i]]$R, penalty, targetmatrix),
                                                 use_ginv = FALSE)
      return(LL)
    }
    return(cvLL / n.folds)
  }
}

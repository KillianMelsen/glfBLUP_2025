#' regPhenCor_ll
#'
#' A small helper function for regPhenCor that calculates the negative log-likelihood.
#'
#' @param S The phenotypic correlation matrix of the left out fold.
#' @param R The regularized phenotypic correlation matrix based on the other folds.
#' @param use_ginv Boolean indicating whether to calculate the generalized inverse
#' if R is singular.
#'
#' @return The calculated log-likelihood.
#'
#' @keywords internal
regPhenCor_ll <- function(S, R, use_ginv = FALSE) {
  if (use_ginv) {
    ll <- log(det(R)) + sum(S*MASS::ginv(R))
  } else {
    ll <- log(det(R)) + sum(S*solve(R))
  }
  return(ll)
}

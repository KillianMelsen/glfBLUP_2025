#' mlFA2
#'
#' Fits a factor model
#'
#' @param R Regularized genetic covariance matrix of RF secondary traits.
#' @param m Number of factors.
#' @param low Lower bound for the uniquenesses.
#'
#' @return List containing the loadings, uniquenesses, and the rotation matrix.
#'
#' @keywords internal
mlFA2 <- function(R, m, low = .005) {
  # Preliminaries for checks
  p    <- ncol(R)
  mmax <- floor((2*p + 1 - sqrt(8*p + 1))/2)

  # Checks
  if (!is.matrix(R)){
    stop("Input (R) should be a matrix")
  }

  if (nrow(R) != ncol(R)){
    stop("Input (R) should be square matrix")
  }

  if (class(m) != "numeric" & class(m) != "integer"){
    stop("Input (m) is of wrong class")
  }

  if (length(m) != 1){
    stop("Length input (m) must be one")
  }

  if (m <= 1){
    stop("Input (m) cannot be lower than or equal to 1")
  }

  if (m > mmax){
    stop("Input (m) is too high")
  }

  # Wrapper
  fit <- stats::factanal(factors = m, covmat = R, rotation = "varimax", lower = low)

  # Return
  rotmatrix <- fit$rotmat
  rownames(rotmatrix) <- colnames(fit$loadings)
  colnames(rotmatrix) <- rownames(rotmatrix)
  return(list(Loadings = fit$loadings,
              Uniqueness = diag(fit$uniquenesses),
              rotmatrix = rotmatrix))
}

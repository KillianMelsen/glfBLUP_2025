#' simFactorData
#'
#' Easily simulate a simple, factorable dataset including secondary traits and a focal trait.
#'
#' @param n.LsF The number of latent signal factors that are genetically and residually
#' correlated to the focal trait.
#' @param n.LnF The number of latent noise factors that are uncorrelated to the focal trait.
#' @param n.SperLF The number of observed secondary traits per latent factor.
#' @param rho.G The genetic correlation between the signal factors and the focal trait.
#' @param rho.E The residual correlation between the signal factors and the focal trait.
#' @param sg2.LF The genetic variance of the latent factors.
#' @param se2.LF The residual variance of the latent factors.
#' @param sg2.sS The genetic variance of the signal secondary traits i.e. the observed traits that are
#' correlated to signal factors.
#' @param se2.sS The residual variance of the signal secondary traits.
#' @param sg2.nS The genetic variance of the noise secondary traits.
#' @param se2.nS The residual variance of the noise secondary traits.
#' @param sg2.focal The genetic variance of the focal trait.
#' @param se2.focal The residual variance of the focal trait.
#' @param M An n x m matrix containing m marker scores for n genotypes.
#' @param K An n x n kinship matrix.
#' @param r The number of replicates per genotype to be simulated.
#' @param rho.G.sF The genetic correlations between signal factors.
#' @param rho.E.sF The residual correlations between signal factors.
#' @param rho.G.nF The genetic correlations between noise factors.
#' @param rho.E.nF The residual correlations between noise factors.
#' @param rho.G.sFnF The genetic correlations between signal and noise factors.
#' @param rho.E.sFnF The residual correatlions between signal and noise factors.
#' @param VgVe.fill Boolean indicating whether to replace any zero covariances
#' between observed secondary traits using a random PD covariance matrix generated
#' using clusterGeneration::genPositiveDefMat. Internal rangeVar argument cannot be
#' too high or Vg and Ve will not be positive-definite, resulting in the data generation
#' failing.
#' @param rangeVar parameter defining the variance range used when \code{VgVe.fill=TRUE}. Default is
#' \code{c(0.05. 0.1)}.
#'
#' @return A list containing the real dataset, a benchmark dataset, the focal trait
#' prediction target, and various genetic and residual covariance matrices.
#'
#' @export
simFactorData <- function(n.LsF, n.LnF, n.SperLF,
                          rho.G, rho.E,
                          sg2.LF, se2.LF,
                          sg2.sS, se2.sS,
                          sg2.nS, se2.nS,
                          sg2.focal, se2.focal,
                          M, K, r,
                          rho.G.sF = NULL, rho.E.sF = NULL,
                          rho.G.nF = NULL, rho.E.nF = NULL,
                          rho.G.sFnF = NULL, rho.E.sFnF = NULL,
                          VgVe.fill = FALSE, rangeVar = c(0.05, 0.1)) {

  # Determine number of secondary traits:
  nS <- (n.LsF + n.LnF) * n.SperLF

  # Determine the total number of traits (+1 for the focal traits):
  p <- nS + n.LsF + n.LnF + 1

  ### Create the dag:
  dag <- matrix(0, p, p)

  rownames(dag) <- colnames(dag) <- c(paste0("LsF", 1:n.LsF),
                                      paste0("LnF", 1:n.LnF),
                                      paste0("S", 1:nS),
                                      "Y")

  ### Create the genetic covariance matrix:
  genCovMatrix              <- matrix(0, p, p)

  diag(genCovMatrix)        <- c(rep(sg2.LF, (n.LsF + n.LnF)),
                                 rep(sg2.sS, (n.SperLF * n.LsF)),
                                 rep(sg2.nS, (n.SperLF * n.LnF)),
                                 sg2.focal)

  # Setting genetic covariance between latent signal factors and focal trait:
  genCovMatrix[p, 1:n.LsF]   <- genCovMatrix[1:n.LsF, p] <- rho.G * sqrt(sg2.LF * sg2.focal)

  ### Create the residual covariance matrix:
  envCovMatrix              <- matrix(0, p, p)

  diag(envCovMatrix)        <- c(rep(se2.LF, (n.LsF + n.LnF)),
                                 rep(se2.sS, (n.SperLF * n.LsF)),
                                 rep(se2.nS, (n.SperLF * n.LnF)),
                                 se2.focal)

  # Setting residual covariance between latent signal factors and focal trait.
  envCovMatrix[p, 1:n.LsF] <- envCovMatrix[1:n.LsF, p] <- rho.E * sqrt(se2.LF * se2.focal)

  #############################################################################

  # Setting genetic and residual covariances between latent factors if specified:
  if (!(is.null(rho.G.sF)) & !(is.null(rho.E.sF))) {

    genCovMatrix[1:n.LsF, 1:n.LsF][upper.tri(genCovMatrix[1:n.LsF, 1:n.LsF])] <-
      genCovMatrix[1:n.LsF, 1:n.LsF][lower.tri(genCovMatrix[1:n.LsF, 1:n.LsF])] <-
      rho.G.sF * sg2.LF

    envCovMatrix[1:n.LsF, 1:n.LsF][upper.tri(envCovMatrix[1:n.LsF, 1:n.LsF])] <-
      envCovMatrix[1:n.LsF, 1:n.LsF][lower.tri(envCovMatrix[1:n.LsF, 1:n.LsF])] <-
      rho.E.sF * se2.LF
  }
  if (!(is.null(rho.G.nF)) & !(is.null(rho.E.nF))) {

    indices <- (n.LsF + 1):(n.LsF + n.LnF)

    genCovMatrix[indices, indices][upper.tri(genCovMatrix[indices, indices])] <-
      genCovMatrix[indices, indices][lower.tri(genCovMatrix[indices, indices])] <-
      rho.G.nF * sg2.LF

    envCovMatrix[indices, indices][upper.tri(envCovMatrix[indices, indices])] <-
      envCovMatrix[indices, indices][lower.tri(envCovMatrix[indices, indices])] <-
      rho.E.nF * se2.LF
  }
  if (!(is.null(rho.G.sFnF)) & !(is.null(rho.E.sFnF))) {

    latents <- (n.LsF + 1):(n.LsF + n.LnF)

    genCovMatrix[1:n.LsF, latents] <- genCovMatrix[latents, 1:n.LsF] <- rho.G.sFnF * sg2.LF
    envCovMatrix[1:n.LsF, latents] <- envCovMatrix[latents, 1:n.LsF] <- rho.E.sFnF * se2.LF
  }

  #############################################################################

  ### Fill the dag:
  for (LF in 1:(n.LsF + n.LnF)){
    start <- (n.LsF + n.LnF + 1) + (LF - 1) * n.SperLF
    end <- start + n.SperLF - 1
    dag[LF, start:end] <- stats::runif(n.SperLF, -0.9, 0.9)
  }

  ### Create the gsem:
  cat("simFactorData: creating GSEM...\n")
  gsem <- create_gsem_h2(dag.adj = dag, genCovMatrix = genCovMatrix, envCovMatrix = envCovMatrix)

  #############################################################################

  if (VgVe.fill) {
    cat("simFactorData: filling Vg and Ve with random noise...\n")
    LF_Y <- c(1:(n.LsF + n.LnF), p)

    ### WERKT!... "onion" omdat "unifcorrmat" veel te langzaam is bij ~1000 traits...
    ### "onion" en "unifcorrmat" lijken verder hetzelfde resultaat te geven...
    Vg.noise <- clusterGeneration::genPositiveDefMat(dim = nS, covMethod = "onion",
                                                     rangeVar = rangeVar)$Sigma

    Ve.noise <- clusterGeneration::genPositiveDefMat(dim = nS, covMethod = "onion",
                                                     rangeVar = rangeVar)$Sigma

    Vg.noise[gsem$Vg[-LF_Y, -LF_Y] != 0] <- 0
    Ve.noise[gsem$Ve[-LF_Y, -LF_Y] != 0] <- 0

    gsem$Vg[-LF_Y, -LF_Y] <- gsem$Vg[-LF_Y, -LF_Y] + Vg.noise
    gsem$Ve[-LF_Y, -LF_Y] <- gsem$Ve[-LF_Y, -LF_Y] + Ve.noise

    ### WERKT NIET...
    # Vg.noise <- clusterGeneration::genPositiveDefMat(dim = nS, covMethod = "onion",
    #                                                  rangeVar = c(0.05, 0.1))$Sigma
    #
    # Ve.noise <- clusterGeneration::genPositiveDefMat(dim = nS, covMethod = "onion",
    #                                                  rangeVar = c(0.05, 0.1))$Sigma
    #
    # Vg.noise[gsem$Vg != 0] <- 0
    # Ve.noise[gsem$Ve != 0] <- 0
    #
    # gsem$Vg <- gsem$Vg + Vg.noise
    # gsem$Ve <- gsem$Ve + Ve.noise

    ### MBV FMradio::FAsim...
    # random.cor <- FMradio::FAsim(p = nS, m = (n.LsF + n.LnF), n = nrow(M))$cormatrix
    # image(random.cor)
    #
    # S.G <- c(rep(sg2.sS, (n.SperLF * n.LsF)), rep(sg2.nS, (n.SperLF * n.LnF)))
    # S.E <- c(rep(se2.sS, (n.SperLF * n.LsF)), rep(se2.nS, (n.SperLF * n.LnF)))
    #
    # random.cov.G <- outer(sqrt(S.G), sqrt(S.G)) * random.cor
    # random.cov.E <- outer(sqrt(S.E), sqrt(S.E)) * random.cor
    #
    # image(random.cov.G)
    #
    # gsem$Vg[-LF_Y, -LF_Y] <- random.cov.G
    # gsem$Ve[-LF_Y, -LF_Y] <- random.cov.E
  }

  # Storing genetic and residual covariance matrices for debugging and
  # for creating the benchmark and secondary trait covariance matrices:
  bm_Vg <- sec_Vg <- gsem$Vg
  bm_Ve <- sec_Ve <- gsem$Ve

  # Creating the benchmark matrices:
  bm_Vg <- bm_Vg[c(paste0("LsF", 1:n.LsF), "Y"), c(paste0("LsF", 1:n.LsF), "Y")]
  bm_Ve <- bm_Ve[c(paste0("LsF", 1:n.LsF), "Y"), c(paste0("LsF", 1:n.LsF), "Y")]

  # Removing latent signal and noise factors as well as focal trait:
  sec_Vg <- sec_Vg[setdiff(rownames(sec_Vg), c(paste0("LsF", 1:n.LsF),
                                               paste0("LnF", 1:n.LnF),
                                               "Y")),
                   setdiff(rownames(sec_Vg), c(paste0("LsF", 1:n.LsF),
                                               paste0("LnF", 1:n.LnF),
                                               "Y"))]

  sec_Ve <- sec_Ve[setdiff(rownames(sec_Ve), c(paste0("LsF", 1:n.LsF),
                                               paste0("LnF", 1:n.LnF),
                                               "Y")),
                   setdiff(rownames(sec_Ve), c(paste0("LsF", 1:n.LsF),
                                               paste0("LnF", 1:n.LnF),
                                               "Y"))]

  ### Checking whether Vg and Ve are both PD:
  # if (min(eigen(gsem$Vg)$values) < 0 | min(eigen(gsem$Ve)$values) < 0) {
  #   cat("Either Vg, Ve, or both are not positive-definite!\n")
  # }

  if (min(try_eigen(gsem$Vg)$values) < 0 | min(try_eigen(gsem$Ve)$values) < 0) {
    cat("Either Vg, Ve, or both are not positive-definite!\n")
    cat("Aborting simulation...\n\n")
    return(list(aborted = TRUE))
  }

  ### Generating the data. Note that the number of genotypes is determined by the size of M:
  cat("simFactorData: generating data...\n\n")
  simData <- rmvDAG_h2(ng = nrow(M), r = r, gsem = gsem, M = M, simFromVgVe = TRUE, K = K)

  # Reformatting the generated data:
  d <- simData$fulldata
  d$G <- factor(as.character(d$G))

  # Subsetting to create the benchmark data:
  d_bm <- d[, c("G", paste0("LsF", 1:n.LsF), "Y")]

  # Then removing latent factors (signal and noise) and block to create the real data:
  d <- d[, setdiff(names(d), c(paste0("LsF", 1:n.LsF), paste0("LnF", 1:n.LnF)
                               , "block"))]

  return(list(Vg.full = gsem$Vg,
              Ve.full = gsem$Ve,
              Vg.sec = sec_Vg,
              Ve.sec = sec_Ve,
              Vg.bm = bm_Vg,
              Ve.bm = bm_Ve,
              pred.target = simData$Gmatrix[,p],
              data.real = d,
              data.bm = d_bm,
              aborted = FALSE,
              gBLUES = simData$Gmatrix))
}

#' siBLUP Development version
#'
#' \code{siBLUP} makes bivariate genomic predictions using a penalized selection index
#' based on the secondary traits.
#'
#' @param d A dataframe containing the genotype, a set of secondary traits, and a focal trait. Must contain replicates.
#' @param geno An optional argument specifying the column containing the genotypes. The default assumes the first column
#' of \code{d} contains the genotypes.
#' @param focal An optional argument specifying the column containing the focal trait. The default assumes the last column
#' of \code{d} contains the focal trait.
#' @param sec An optional argument specifying the column indices of the columns in \code{d} that contain the secondary traits.
#' The default assumes all columns of \code{d} except the first and last contain the secondary traits.
#' @param K The kinship matrix of training and test genotypes.
#' @param reg.target Argument specifying the regularization target to be used. Default is \code{"identity"}. \code{"hyperspectral"} might
#' be a future option. Can also be a matrix.
#' @param CV CV scenario. Leave at default of \code{"CV1"} for now.
#' @param verbose Display information or not.
#' @param do.parallel Use paralellization or not.
#' @param use_nearPD use_nearPD Boolean indicating whether to use nearPD calls to enforce PDness
#' of the calculated genetic covariance matrix.
#' @param use_ginv Boolean indicating whether to calculate the generalized inverse
#' if R is singular.
#'
#' @return A list containing the test set predictions, the optimal regularization penalty, and the secondary trait weights.
#'
#' @importFrom stats aggregate cor cov2cor na.omit optim
#'
#' @export
#'
siBLUP_DEV <- function(d, geno = names(d)[1], focal = names(d)[ncol(d)], sec = 2:(length(names(d)) - 1),
                       K, reg.target = "identity", CV = "CV1", verbose = TRUE, do.parallel = FALSE,
                       use_nearPD = TRUE, use_ginv = FALSE) {

  #############################################################################
  ### 1. Argument checking ####################################################
  #############################################################################

  stopifnot(class(d) == "data.frame",
            class(geno) == "character",
            class(focal) == "character",
            class(sec) %in% c("integer", "numeric"),
            class(K) == c("matrix", "array"),
            reg.target %in% c("identity", "hyperspectral") | class(reg.target)[1] == "matrix",
            CV %in% c("CV1", "CV2"),
            class(verbose) == "logical",
            class(do.parallel) == "logical")

  #############################################################################
  ### 2. Reformatting data and collecting necesarry information ###############
  #############################################################################

  # Reformat input data so it only includes genotype, secondary traits, and the
  # focal trait:
  d <- cbind(d[, geno], d[, sec], d[, focal])
  names(d)[1] <- "G"
  names(d)[ncol(d)] <- focal

  # Determine the number of traits (secondary + focal):
  p <- ncol(d) - 1

  # Storing training and testing genotypes:
  train.set <- as.character(unique(d$G[!is.na(d[, focal])]))
  test.set <- as.character(setdiff(unique(d$G), train.set))

  # Setting all trait values or just the focal trait values to NA for test set
  # depending on the CV-scenario:
  if (CV == "CV1") {
    d[d$G %in% test.set, setdiff(names(d), "G")] <- NA
  }

  # Changing genotype to factor and dropping any levels if necessary:
  d$G <- as.factor(d$G)
  d <- droplevels(d)

  #############################################################################
  ### 3. Redundancy filtering #################################################
  #############################################################################

  if (verbose) {
    cat("Starting redundancy filtering...\n")
  }

  # Retrieve genetic covariance matrix for secondary traits for redundancy
  # filtering:
  if (CV == "CV1") {
    Vg.all.sec <- covFromSS(data = d[1:p], use_nearPD = TRUE)$Vg
  } else if (CV == "CV2") {
    # For now let's use just the training set, even in CV2...
    Vg.all.sec <- covFromSS(data = d[which(d$G %in% train.set), 1:p], use_nearPD = TRUE)$Vg
  }

  # Redundancy filtering the genetic correlation matrix of secondary traits:
  Rg.filter.sec <- FMradio::RF(cov2cor(Vg.all.sec))

  if (verbose) {
    cat(dim(Rg.filter.sec)[1], "out of", dim(Vg.all.sec)[1],
        "secondary traits remain after redundancy filtering...\n")
  }

  # Subsetting data after redundancy filtering:
  d.subset <- as.data.frame(FMradio::subSet(as.matrix(d[, 2:p]), Rg.filter.sec))

  # Adding back genotype and focal trait:
  d.subset <- as.data.frame(cbind(d$G, d.subset, d[, focal]))
  names(d.subset)[1] <- "G"
  names(d.subset)[ncol(d.subset)] <- focal

  # Removing rows with missing data (test genotypes) for regularization:
  d.subset.train <- na.omit(d.subset)
  d.subset.train <- droplevels(d.subset.train)

  # Subsetting user specified regularization target (if specified):
  if (class(reg.target)[1] == "matrix") {
    remove <- rownames(reg.target)[!(rownames(reg.target) %in% rownames(Rg.filter.sec))]
    reg.target <- reg.target[setdiff(rownames(reg.target), remove),
                             setdiff(colnames(reg.target), remove)]

  }

  if (verbose) {
    cat("Dimensions of redundancy filtered training subset are ", dim(d.subset.train)[1],
        " by ", dim(d.subset.train)[2], "...\n\n", sep = "")
  }

  #############################################################################
  ### 4. Regularizing Vp on replicate level (no Ve / n.rep ####################
  #############################################################################

  # Regularizing phenotypic correlation matrix of remaining secondary traits:
  if (verbose) {
    cat("Regularizing phenotypic correlation matrix of remaining secondary traits...\n")
    if (class(reg.target)[1] == "matrix") {
      cat("Using user-specified regularization target...\n")
    } else {
      cat("Using", reg.target, "regularization target...\n")
    }
  }

  # Due to line 104-106 (subsetting to training set) regularization is done using only the training set, even in CV2:
  OPT <- regPhenCor(X = as.matrix(d.subset.train[, 1:(dim(Rg.filter.sec)[1] + 1)]),
                    fold = 5, targetmatrix = reg.target, verbose = verbose,
                    do.parallel = do.parallel, use_nearPD = use_nearPD, use_ginv = use_ginv)

  if (verbose) {
    cat("Optimal penalty value set at: ", OPT$optPen, "...\n\n", sep = "")
  }
  Rp.reg <- OPT$optCor

  # Retrieving variances:
  S <- diag(OPT$RFsubset_cov_p)

  # Reconverting regularized phenotypic correlation matrix to covariance matrix:
  Vp.reg <- outer(sqrt(S), sqrt(S)) * Rp.reg

  #############################################################################
  ### 5. Calculating the genetic covariances between the remaining ############
  ### secondary traits and the focal trait.                        ############
  #############################################################################

  COVg_secfocal <- covFromSS(data = d.subset.train, use_nearPD = TRUE)$Vg
  n.sec <- nrow(COVg_secfocal) - 1
  COVg_secfocal <- matrix(COVg_secfocal[1:n.sec, ncol(COVg_secfocal)])

  cat("Dimensions of COVg_secfocal are:", dim(COVg_secfocal), "\n\n")

  #############################################################################
  ### 6. Calculate the penalized column vector of selection index weights #####
  #############################################################################

  penGAMMA <- solve(Vp.reg) %*% COVg_secfocal
  rownames(penGAMMA) <- names(d.subset.train[, setdiff(colnames(d.subset.train), c("G", focal))])

  cat("Dimensions of penGAMMA are:", dim(penGAMMA), "\n\n")

  #############################################################################
  ### 7. Calculate the penalized selection index for all individuals ##########
  #############################################################################

  if (CV == "CV1") {
    penSI <- as.matrix(d.subset.train[, setdiff(colnames(d.subset.train), c("G", focal))]) %*% penGAMMA

    d.SI <- data.frame(G = d[which(d$G %in% train.set), geno],
                       penSI = penSI,
                       focal = d[which(d$G %in% train.set), focal])

  } else if (CV == "CV2") {
    penSI <- as.matrix(d.subset[, setdiff(colnames(d.subset), c("G", focal))]) %*% penGAMMA

    d.SI <- data.frame(G = d[, geno],
                       penSI = penSI,
                       focal = d[, focal])
  }

  names(d.SI)[ncol(d.SI)] <- focal

  cat("Dimensions of d.SI are:", dim(d.SI), "\n\n")

  if (CV == "CV1") {
    dm <- genoMeans(data = d.SI)
    dm$G <- as.character(dm$G)
    dm <- dm[match(train.set, dm$G),]
    rownames(dm) <- train.set
  } else if (CV == "CV2") {
    dm <- genoMeans(data = d.SI)
    dm$G <- as.character(dm$G)
    dm <- dm[match(c(test.set, train.set), dm$G),]
    rownames(dm) <- c(test.set, train.set)
  }

  cat("Dimensions of dm are:", dim(dm), "\n\n")

  # Calculating Vg and Ve to be used in subset selection and gBLUP calculations:
  if (CV == "CV1") {
    temp <- covFromSS(data = d.SI, calc.Ve = TRUE, use_nearPD = TRUE)
  } else if (CV == "CV2") {
    temp <- covFromSS(data = d.SI[which(d$G %in% train.set), ], calc.Ve = TRUE, use_nearPD = TRUE)
  }
  Vg <- temp$Vg
  Ve <- temp$Ve

  cat("Dimensions of Vg are:", dim(Vg), "\n\n")

  # Determining number of replicates:
  n.rep.vector <- as.integer(table(d$G))
  n.rep <- (sum(n.rep.vector) - sum(n.rep.vector^2) / sum(n.rep.vector)) / (length(n.rep.vector) - 1)

  #############################################################################
  ### 8. BLUP calculations ####################################################
  #############################################################################

  if (min(eigen(Vg)$values) < 0) {
    if (verbose) {
      cat("Genetic covariance matrix is not positive-definite. Using nearPD()...\n")
    }
    Vg <- as.matrix(Matrix::nearPD(x = Vg)$mat)
  }

  if (verbose) {
    cat("Making final test set predictions...\n\n")
  }

  if (CV == "CV1") {
    # Calculating focal trait BLUP for the training set:
    focalBLUP_train <- fast_o_gBLUP(Y = as.matrix(dm[, -1]),
                                    K = K,
                                    Vg = Vg,
                                    Ve = Ve / n.rep,
                                    train.set = train.set,
                                    targetName = focal)

    # Calculating focal trait BLUP for the test set:
    focalBLUP_test <- train2test(focalBLUP_train$focal_gBLUP, K = K,
                                 train.set = train.set, test.set = test.set)
  } else if (CV == "CV2") {
    # Calculating focal trait BLUP for the training set:
    BLUPs_train <- fast_o_gBLUP(Y = as.matrix(dm[train.set, -1]),
                                K = K,
                                Vg = Vg,
                                Ve = Ve / n.rep,
                                train.set = train.set,
                                targetName = focal)

    # Calculating all BLUPs for the test set:
    BLUPs_test <- train2test(BLUPs_train$all_gBLUPs, K = K,
                             train.set = train.set, test.set = test.set)

    BLUP_Y_test <- BLUPs_test[, focal]
    BLUP_S_test <- BLUPs_test[, setdiff(colnames(BLUPs_test), focal)]
    Ktt <- K[test.set, test.set]
    Kto <- K[test.set, train.set]
    Koo <- K[train.set, train.set]
    Vc <- kronecker(Vg["penSI", "penSI"], solve(Ktt)) + kronecker(Ve["penSI", "penSI"] / n.rep, diag(dim(Ktt)[1]))

    # Final CV2 test set focal trait BLUP calculation following two-step approach (Runcie & Cheng, 2019):
    focalBLUP_test <- as.numeric(matrix(BLUP_Y_test) + kronecker(t(as.matrix(Vg["penSI", focal])), solve(Ktt)) %*%
                                   solve(Vc) %*% (matrix(as.matrix(dm[test.set, "penSI"])) - matrix(BLUP_S_test)))

    names(focalBLUP_test) <- test.set
  }

  return(list(preds = focalBLUP_test,
              regPen = OPT$optPen,
              gamma = penGAMMA))
}











#' regGenCor_kcvl
#'
#' A helper function for regGenCor that calculates the mean cross-validated
#' negative log-likelihood that is used to find the optimal penalty.
#'
#' @param penalty The penalty that must me optimized.
#' @param X The same matrix as passed to regGenCor.
#' @param folds Number of folds passed from regGenCor.
#' @param targetmatrix The regularization target as passed from regGenCor.
#' @param mu.geno Dataframe containing the genotype means. This is calculated only
#' once in regGenCor.
#' @param n.rep Mean number of replicates per genotype. Also calculated in regGenCor.
#' @param do.parallel boolean indicating whether to use parallelization or not.
#' @param use_nearPD use_nearPD Boolean indicating whether to use nearPD calls to enforce PDness
#' of the calculated genetic covariance matrix.
#' @param use_ginv Boolean indicating whether to calculate the generalized inverse
#' if R is singular.
#' @param use_means Boolean indicating whether to calculate Vg using the sums of squares or
#' by using the function cov on the matrix of genotypic means.
#'
#' @return The mean cross-validated negative log-likelihood.
#'
#' @importFrom foreach %dopar%
#'
#' @keywords internal
regGenCor_kcvl <- function(penalty, X, folds, targetmatrix, mu.geno, n.rep, do.parallel, use_nearPD, use_ginv, use_means) {
  if (!(do.parallel)) {
    cvLL <- 0
    for (f in 1:length(folds)){
      # Make dataframe for 4/5 folds:
      R_dataframe <- as.data.frame(X)[!(X[,1] %in% folds[[f]]), , drop = FALSE]
      R_dataframe$G <- factor(as.character(R_dataframe$G))
      secondaries <- names(R_dataframe)[2:length(names(R_dataframe))]
      R_dataframe[secondaries] <- lapply(R_dataframe[secondaries], as.numeric)

      # Calculating R:
      Vg.R <- covFromSS(data = R_dataframe, mu.geno = mu.geno, n.rep = n.rep,
                        use_nearPD = use_nearPD, use_means = use_means)$Vg
      R <- cov2cor(Vg.R)

      # Making dataframe for the left out fold:
      S_dataframe <- as.data.frame(X)[X[,1] %in% folds[[f]], , drop = FALSE]
      S_dataframe$G <- factor(as.character(S_dataframe$G))
      secondaries <- names(S_dataframe)[2:length(names(S_dataframe))]
      S_dataframe[secondaries] <- lapply(S_dataframe[secondaries], as.numeric)

      # Calculating S:
      Vg.S <- covFromSS(data = S_dataframe, mu.geno = mu.geno, n.rep = n.rep,
                        use_nearPD = use_nearPD, use_means = use_means)$Vg
      S <- cov2cor(Vg.S)

      nf   <- dim(as.data.frame(X)[X[,1] %in% folds[[f]], , drop = FALSE])[1]
      cvLL <- cvLL + nf * regGenCor_ll(S, regGenCor_corlw(R, penalty, targetmatrix), use_ginv = use_ginv)
    }
    return(cvLL/length(folds))
  } else if (do.parallel) {
    ### PARALLELIZATION
    cvLL <- foreach::foreach(f = 1:length(folds), .combine = "+", .packages = c("gfBLUP")) %dopar% {
      # Make dataframe for 4/5 folds:
      R_dataframe <- as.data.frame(X)[!(X[,1] %in% folds[[f]]), , drop = FALSE]
      R_dataframe$G <- factor(as.character(R_dataframe$G))
      secondaries <- names(R_dataframe)[2:length(names(R_dataframe))]
      R_dataframe[secondaries] <- lapply(R_dataframe[secondaries], as.numeric)

      # Calculating R:
      Vg.R <- gfBLUP:::covFromSS(data = R_dataframe, mu.geno = mu.geno, n.rep = n.rep,
                                 use_nearPD = use_nearPD, use_means = use_means)$Vg
      R <- cov2cor(Vg.R)

      # Making dataframe for the left out fold:
      S_dataframe <- as.data.frame(X)[X[,1] %in% folds[[f]], , drop = FALSE]
      S_dataframe$G <- factor(as.character(S_dataframe$G))
      secondaries <- names(S_dataframe)[2:length(names(S_dataframe))]
      S_dataframe[secondaries] <- lapply(S_dataframe[secondaries], as.numeric)

      # Calculating S:
      Vg.S <- gfBLUP:::covFromSS(data = S_dataframe, mu.geno = mu.geno, n.rep = n.rep,
                                 use_nearPD = use_nearPD, use_means = use_means)$Vg
      S <- cov2cor(Vg.S)

      nf   <- dim(as.data.frame(X)[X[,1] %in% folds[[f]], , drop = FALSE])[1]
      LL <- nf * gfBLUP:::regGenCor_ll(S, gfBLUP:::regGenCor_corlw(R, penalty, targetmatrix), use_ginv = use_ginv)
      return(LL)
    }
    return(cvLL/length(folds))
  }
}

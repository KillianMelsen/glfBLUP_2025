#' subset_leaps
#'
#' Wrapper for the leaps::leaps function that quickly selects the best subset of factors.
#'
#' @param d A dataframe containing the mean factor scores and mean focal trait
#' values for each genotype.
#' @param factors A character vector with the column names of the factors in d.
#' @param focal A character with the name of the focal trait in d.
#'
#' @return A character vector containing the names of the factors in the best subset.
#'
#' @keywords internal
subset_leaps <- function(d, factors, focal) {

  temp <- leaps::leaps(x = as.matrix(d[, factors]),
                       y = as.matrix(d[, focal]),
                       method = "adjr2", names = factors,
                       int = TRUE)

  F.select.logical <- temp$which[which(temp$adjr2 == max(temp$adjr2)),]
  F.select <- factors[F.select.logical]

  return(F.select)
}

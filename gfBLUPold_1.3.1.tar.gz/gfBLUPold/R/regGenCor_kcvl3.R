#' regGenCor_kcvl
#'
#' A helper function for regGenCor that calculates the mean cross-validated
#' negative log-likelihood that is used to find the optimal penalty.
#'
#' @param penalty The penalty that must me optimized.
#' @param targetmatrix The regularization target as passed from regGenCor.
#' @param vecs The list containing the pre-calculated vectors for each fold, eigen values of R and the diagonal of A.
#'
#' @return The mean cross-validated negative log-likelihood.
#'
#' @importFrom foreach %dopar%
#'
#' @keywords internal
regGenCor_kcvl3 <- function(penalty, targetmatrix, vecs) {
  n.folds <- length(vecs)
  cvLL <- 0
  for (i in 1:n.folds){

    cvLL <- cvLL + vecs[[i]]$nf * regGenCor_ll3(penalty = penalty,
                                                targetmatrix = targetmatrix,
                                                R.eigenvalues = vecs[[i]]$R.EV,
                                                A.diag = vecs[[i]]$A.diag)
  }
  return(cvLL / n.folds)
}

#' Title
#'
#' @param dag.adj qqq
#' @param genCovMatrix qqq
#' @param envCovMatrix qqq
#'
#' @return q
#'
#' @keywords internal
create_gsem_h2 <- function(dag.adj, genCovMatrix, envCovMatrix) {
  # dag.adj      : p x p matrix defining the DAG among the p traits (with weights!), or
  #                a graphNEL object
  # genCovMatrix : p x p matrix defining the direct genetic effects on the p traits,
  #                and the genetic covariance between these direct effects (if the gen. variance is nonzero)

  #get.adjacency(graph_from_graphnel(dag))


  # to do:
  # check if graph is topologically sorted!
  # dag.adj should be upper triangular !

  if (class(dag.adj)[1] =='graphNEL') {
    p           <- graph::numNodes(dag.adj)
    dag.adj     <- getLambda(dag.adj)
    #as.matrix(get.adjacency(graph_from_graphnel(dag.adj)))
    GammaMatrix <- solve(diag(p) - dag.adj)
  } else {# class == 'matrix'
    p           <- ncol(dag.adj)
    GammaMatrix <- solve(diag(p) - dag.adj)
  }
  Lambda <- dag.adj
  #igraph.to.graphNEL(dag.adj)

  gdag <- cbind(matrix(rep(0,p+1), nrow=p+1),
                rbind(matrix(sign(diag(genCovMatrix)), nrow=1), dag.adj))

  colnames(gdag)[1] <- rownames(gdag)[1] <- 'genotype'

  gdag[gdag!=0] <- 1

  gdag <- igraph::graph_from_adjacency_matrix(gdag)

  #adj.true <- get.adjacency(gdag)

  auxMatrix <- matrix(0, p, p)
  auxMatrix[(dag.adj!=0)] <- 1
  rownames(auxMatrix) <- colnames(auxMatrix) <- rownames(dag.adj)
  auxDag <- igraph::graph_from_adjacency_matrix(auxMatrix)

  #plot(graph_from_adjacency_matrix(auxMatrix))

  #dag <- graph_from_adjacency_matrix(dag.adj) #plotGraph(dag)

  #dag <- igraph.to.graphNEL(dag)

  if (min(eigen(genCovMatrix)$values) < 0) {
    cat("genCovMatrix is not positive-definite. Using nearPD...\n")
    genCovMatrix <- as.matrix(Matrix::nearPD(genCovMatrix)$mat)
  }
  if (min(eigen(envCovMatrix)$values) < 0) {
    cat("envCovMatrix is not positive-definite. Using nearPD...\n")
    envCovMatrix <- as.matrix(Matrix::nearPD(envCovMatrix)$mat)
  }

  gsem.obj <- list(dag = igraph::igraph.to.graphNEL(auxDag), gdag = igraph::igraph.to.graphNEL(gdag),
                   Lambda = Lambda,
                   genCovMatrix = genCovMatrix, envCovMatrix = envCovMatrix,
                   Vg = t(GammaMatrix) %*% genCovMatrix %*% GammaMatrix,
                   Ve = t(GammaMatrix) %*% envCovMatrix %*% GammaMatrix,
                   gammaMatrix = GammaMatrix)

  return(gsem.obj)
}

#' covFromSS
#'
#' Efficiently calculates Vg and possibly Ve using sums of squares. Does not fit
#' any linear models.
#'
#' @param data A dataframe where the first column contains the genotypes. All
#' other columns must contain secondary trait measurements. Must contain genotype
#' replicates!
#' @param mu.geno A dataframe containing per-genotype means. If left at default
#' of NULL the means are calculated internally.
#' @param n.rep The mean number of replicates per genotype. If left at default
#' of NULL it is calculated internally.
#' @param calc.Ve Boolean indicating whether to calculate Ve as well.
#' @param use_nearPD Boolean indicating whether to use nearPD calls to enforce PDness
#' of the calculated genetic covariance matrix.
#' @param use_means Boolean indicating whether to calculate Vg using the sums of squares or
#' by using the function cov on the matrix of genotypic means.
#' @param sepExp IMPORTANT! Boolean that must be set to TRUE if the focal trait was measured
#' in a different experiment/on different plants than the secondary traits. If that is the case,
#' the residual covariances between the focal and secondary traits, in the MSE matrix, are set to 0.
#'
#' @return A list containing Vg and if calc.Ve == TRUE also Ve.
#'
#' @keywords internal
covFromSS <- function(data, mu.geno = NULL, n.rep = NULL, calc.Ve = FALSE,
                      use_nearPD = TRUE, use_means = FALSE, sepExp = FALSE) {
  data <- na.omit(data)
  data <- droplevels(data)
  # Determine number of traits (number of columns - 1 because of genotype):
  n.traits <- ncol(data) - 1

  # Calculate genotype means if mu.geno is NULL:
  if (is.null(mu.geno)) {
    mu.geno <- genoMeans(data)
  }

  if (use_means) {
    Vg2 <- cov(mu.geno[, -1])

    # Do some stuff (copied from manova_cov()):
    Vg2 <- (Vg2 + t(Vg2)) / 2

    if (use_nearPD) {
      if (min(eigen(Vg2)$values) < 0) {
        Vg2 <- as.matrix(Matrix::nearPD(Vg2, keepDiag = FALSE)$mat)
        #cat("covFromSS using nearPD\n")
      }
      temp <- which(diag(Vg2) < 0)
      if (length(temp) > 0) {
        Vg2[temp, ] <- 0
        Vg2[, temp] <- 0
        if (min(eigen(Vg2)$values) < 0) {
          Vg2 <- as.matrix(Matrix::nearPD(Vg2, keepDiag = TRUE)$mat)
          #cat("covFromSS using nearPD\n")
        }
      }
    }
    return(list(Vg = Vg2))
  }

  # Determine number of replicates if n.rep is NULL:
  if (is.null(n.rep)) {
    n.rep.vector <- as.integer(table(data[, 1]))
    n.rep <- (sum(n.rep.vector) - sum(n.rep.vector^2) / sum(n.rep.vector)) / (length(n.rep.vector) - 1)
  }

  # Calculate total SS:
  mu.overall <- rep(NA, n.traits)
  for (i in 2:(n.traits + 1)) {
    mu.overall[i - 1] <- mean(data[, i])
  }
  diffs.T <- as.matrix(data[, -1]) - kronecker(matrix(rep(1, nrow(data))), t(matrix(mu.overall)))
  SS.T <- t(diffs.T) %*% (diffs.T)

  # Calculate error SS:
  # Create matrix with genotype means that is conformable to data:
  mu.geno.matched <- mu.geno[match(data[, 1], mu.geno[, 1]),]
  rownames(mu.geno.matched) <- rownames(data)

  diffs.E <- as.matrix(data[, -1]) - as.matrix(mu.geno.matched[, -1])
  SS.E <- t(diffs.E) %*% (diffs.E)

  # Calculate genotype SS:
  SS.G <- SS.T - SS.E

  # Calculate MSgenotype and MSerror:
  MS.G <- SS.G / (length(unique(data[, 1])) - 1)
  MS.E <- SS.E / (nrow(data) - length(unique(data[, 1])))

  if (sepExp) {
    MS.E[nrow(MS.E), 1:(ncol(MS.E) - 1)] <- MS.E[1:(nrow(MS.E) - 1), ncol(MS.E)] <- 0
  }

  # Calculate Vg
  Vg <- (MS.G - MS.E) / n.rep

  # Do some stuff (copied from manova_cov()):
  Vg <- (Vg + t(Vg)) / 2

  if (use_nearPD) {
    if (min(eigen(Vg)$values) < 0) {
    Vg <- as.matrix(Matrix::nearPD(Vg, keepDiag = FALSE)$mat)
    #cat("covFromSS using nearPD\n")
    }
    temp <- which(diag(Vg) < 0)
    if (length(temp) > 0) {
      Vg[temp, ] <- 0
      Vg[, temp] <- 0
      if (min(eigen(Vg)$values) < 0) {
        Vg <- as.matrix(Matrix::nearPD(Vg, keepDiag = TRUE)$mat)
        #cat("covFromSS using nearPD\n")
      }
    }
  }


  if (calc.Ve) {
    Ve <- MS.E
    return(list(Vg = Vg, Ve = Ve))
  } else {
    return(list(Vg = Vg))
  }
}

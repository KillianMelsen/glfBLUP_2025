#' regPhenCor
#'
#' Regularizes the phenotypic covariance matrix of remaining secondary traits.
#'
#' @param X A matrix where the first column contains the genotypes. All other columns must contain
#' secondary trait measurements. Must not contain any NA values, so must only contain training
#' genotypes.
#' @param fold Number of folds to use.
#' @param targetmatrix Character indicating what regularization target to use.
#' Leave on \code{"identity"} for now.
#' @param verbose Boolean indicating whether to display information or not.
#' @param do.parallel Boolean indicating whether to use parallelization or not.
#' @param use_nearPD use_nearPD Boolean indicating whether to use nearPD calls to enforce PDness
#' of the calculated genetic covariance matrix.
#' @param use_ginv Boolean indicating whether to calculate the generalized inverse
#' if R is singular.
#' @param reg.penalty Optional argument in case a user-specified regularization penalty must be used. If left at default value of NULL
#' the optimal penalty will be determined using 5-fold CV. If specifying a penalty, note that it must be between 0 and 1.
#'
#' @importFrom stats cov
#'
#' @return A list containing the optimal penalty value, the regularized phenoypic
#' correlation matrix, and a non-regularized RF filtered phenotypic covariance matrix for
#' easy conversion of optCor back to a covariance matrix.
#'
#' @keywords internal
regPhenCor <- function(X, fold, targetmatrix = "identity", verbose = FALSE, do.parallel,
                       use_nearPD = TRUE, use_ginv = FALSE, reg.penalty = NULL) {

  if (!is.matrix(X)) {
    stop("Input (X) should be a matrix")
  }
  if (class(fold) != "numeric" & class(fold) != "integer") {
    stop("Input (fold) is of wrong class")
  }
  if (fold <= 1) {
    stop("Input (fold) should be at least 2")
  }
  if (fold > nrow(X)) {
    stop("Input (fold) cannot exceed the sample size")
  }
  if (class(verbose) != "logical") {
    stop("Input (verbose) is of wrong class")
  }
  if (verbose) {
    cat("Determining folds...", "\n")
  }
  # Convert X to dataframe and make secondary traits numeric:
  d_reg <- as.data.frame(X)
  traits <- names(d_reg)[2:length(names(d_reg))]
  d_reg[traits] <- lapply(d_reg[traits], as.numeric)

  # Calculate genotype means:
  mu.geno <- genoMeans(data = d_reg)

  # Determine number of reps:
  n.rep.vector <- as.integer(table(d_reg$G))
  n.rep <- (sum(n.rep.vector) - sum(n.rep.vector^2)/sum(n.rep.vector))/(length(n.rep.vector) - 1)

  if(is.null(reg.penalty)) {

    # Create folds:
    ngeno <- length(as.integer(table(as.data.frame(X)$G)))
    fold <- max(min(ceiling(fold), ngeno), 2)
    fold <- rep(1:fold, ceiling(ngeno/fold))[1:ngeno]
    shuffle <- sample(unique(as.data.frame(X)$G), ngeno)
    folds <- split(shuffle, as.factor(fold))

    if (verbose) {
      cat("Determining optimal penalty value...\n")
    }

    if (do.parallel) {
      cores <- min(5, parallel::detectCores() - 2)
      doParallel::registerDoParallel(cores = cores)
      cat("Parallelizing the optimization process.", cores, "cores used...\n")
    }

    optLambda <- optim(0.5, regPhenCor_kcvl, method = "Brent", lower = 0, upper = 1,
                       X = X, folds = folds, targetmatrix = targetmatrix,
                       mu.geno = mu.geno, n.rep = n.rep, do.parallel = do.parallel,
                       use_nearPD = use_nearPD, use_ginv = use_ginv)$par

    doParallel::stopImplicitCluster()
  } else {
    optLambda <- reg.penalty
  }

  # Also return genetic covariance matrix of RF subsetted data for easy
  # conversion of optCor to covariance matrix:
  d_reg$G <- factor(as.character(d_reg$G))
  temp <- covFromSS(data = d_reg, mu.geno = mu.geno, n.rep = n.rep, calc.Ve = TRUE, use_nearPD = use_nearPD)
  RFsubset_Vp <- temp$Vg + temp$Ve

  return(list(optPen = optLambda,
              optCor = regPhenCor_corlw(cov2cor(RFsubset_Vp), optLambda, targetmatrix),
              RFsubset_cov_p = RFsubset_Vp))
}

#' lsBLUP
#'
#' \code{lsBLUP} makes bivariate genomic predictions using a LASSO prediction (LSP) of the focal trait,
#' based on the secondary traits.
#'
#' @param d A dataframe containing the genotype, a set of secondary traits, and a focal trait. Must contain replicates.
#' @param geno An optional argument specifying the column containing the genotypes. The default assumes the first column
#' of \code{d} contains the genotypes.
#' @param focal An optional argument specifying the column containing the focal trait. The default assumes the last column
#' of \code{d} contains the focal trait.
#' @param sec An optional argument specifying the column indices of the columns in \code{d} that contain the secondary traits.
#' The default assumes all columns of \code{d} except the first and last contain the secondary traits.
#' @param K The kinship matrix of training and test genotypes.
#' @param CV CV scenario. \code{"CV1"} or \code{"CV2"}.
#' @param verbose Display information or not.
#' @param sepExp IMPORTANT! Boolean that must be set to TRUE if the focal trait was measured
#' in a different experiment/on different plants than the secondary traits. If that is the case,
#' the residual covariances between the focal and secondary traits, in the MSE matrix in the
#' covFromSS function, are set to 0.
#' @param do.parallel Use paralellization or not.
#' @param lambda Specifies which value of lambda should be used. Should be either \code{"min"} or \code{"1se"}.
#' Defaults to \code{"min"}.
#' @param t.RF Threshold value for redundancy filtering. Defaults to \code{0.95}.
#'
#' @return A list containing the test set predictions, LASSO coefficients, genetic and residual covariance matrices of
#' the LSP and focal trait, heritabilities, LSP matrix, and accuracy measures for direct and indirect selection.
#'
#' @importFrom stats aggregate cor cov2cor na.omit optim
#'
#' @export
#'
lsBLUP <- function(d,
                   geno = names(d)[1],
                   focal = names(d)[ncol(d)],
                   sec = 2:(length(names(d)) - 1),
                   K,
                   CV = "CV1",
                   verbose = TRUE,
                   sepExp = FALSE,
                   do.parallel = FALSE,
                   lambda = "min",
                   t.RF = 0.95) {

  # Argument Checking ----------------------------------------------------------

  stopifnot(class(d) == "data.frame",
            class(geno) == "character",
            class(focal) == "character",
            class(sec) %in% c("integer", "numeric"),
            class(K) == c("matrix", "array"),
            CV %in% c("CV1", "CV2"),
            class(verbose) == "logical",
            class(sepExp) == "logical",
            class(do.parallel) == "logical")

  # Reformatting Data ----------------------------------------------------------

  # Reformat input data so it only includes genotype, secondary traits, and the
  # focal trait:
  d <- cbind(d[, geno], d[, sec], d[, focal])
  names(d)[1] <- "G"
  names(d)[ncol(d)] <- focal

  # Determining the number of traits (secondary + focal):
  p <- ncol(d) - 1

  # Storing training and testing genotypes:
  train.set <- as.character(unique(d$G[!is.na(d[, focal])]))
  test.set <- as.character(setdiff(unique(d$G), train.set))

  # Setting all trait values or just the focal trait values to NA for test set
  # depending on the CV-scenario:
  if (CV == "CV1") {
    d[d$G %in% test.set, setdiff(names(d), "G")] <- NA
  }

  # Changing genotype to factor and dropping any levels if necessary:
  d$G <- as.factor(d$G)
  d <- droplevels(d)

  # Redundancy Filtering -------------------------------------------------------

  if (verbose) {
    cat("Starting redundancy filtering...\n")
  }

  # Retrieve genetic covariance matrix for secondary traits for redundancy
  # filtering:
  if (CV == "CV1") {
    Vg.all.sec <- covFromSS(data = d[1:p], use_nearPD = TRUE)$Vg
  } else if (CV == "CV2") {
    # For now let's use just the training set, even in CV2...
    Vg.all.sec <- covFromSS(data = d[which(d$G %in% train.set), 1:p], use_nearPD = TRUE)$Vg
  }

  # Redundancy filtering the genetic correlation matrix of secondary traits:
  Rg.filter.sec <- FMradio::RF(cov2cor(Vg.all.sec), t = t.RF)

  if (verbose) {
    cat(dim(Rg.filter.sec)[1], "out of", dim(Vg.all.sec)[1],
        "secondary traits remain after redundancy filtering...\n")
  }

  # Subsetting data after redundancy filtering:
  d.subset <- as.data.frame(FMradio::subSet(as.matrix(d[, 2:p]), Rg.filter.sec))

  # Adding back genotype and focal trait:
  d.subset <- as.data.frame(cbind(d$G, d.subset, d[, focal]))
  names(d.subset)[1] <- "G"
  names(d.subset)[ncol(d.subset)] <- focal

  # Removing rows with missing data (test genotypes) so only training data remains:
  d.subset.train <- na.omit(d.subset)
  d.subset.train <- droplevels(d.subset.train)

  if (verbose) {
    cat("Dimensions of redundancy filtered training subset are ", dim(d.subset.train)[1],
        " by ", dim(d.subset.train)[2], "...\n\n", sep = "")
  }

  # Lasso Regression -----------------------------------------------------------

  # Making a data matrix with genotypic means:
  dm <- genoMeans(d.subset.train)

  if (verbose) {
    cat("Calculating LASSO coefficients...\n\n")
  }

  # Running glmnet, possibly parallelized:
  if (do.parallel) {
    doParallel::registerDoParallel(parallel::detectCores() - 2)

    LS <- glmnet::cv.glmnet(x = as.matrix(dm[, 2:(ncol(dm) - 1)]),
                            y = as.matrix(dm[, ncol(dm)]),
                            alpha = 1, nfolds = 5, parallel = TRUE)

    doParallel::stopImplicitCluster()
  } else {
    LS <- glmnet::cv.glmnet(x = as.matrix(dm[, 2:(ncol(dm) - 1)]),
                            y = as.matrix(dm[, ncol(dm)]),
                            alpha = 1, nfolds = 5, parallel = FALSE)
  }

  # Extracting coefficients:
  if (lambda == "1se") {
    coefs <- LS$glmnet.fit$beta[, which(LS$lambda == LS$lambda.1se)]
  } else if (lambda == "min") {
    coefs <- LS$glmnet.fit$beta[, which(LS$lambda == LS$lambda.min)]
  }

  if (all(coefs == 0)) {
    # Run a univariate gBLUP if all LS coefficients are 0:
    UNI <- rrBLUP::kin.blup(data = d, geno = "G", pheno = focal, K = K)
    preds <- UNI$g[test.set]
    names(preds) <- test.set
  } else {
    # Creating dataframe for the lasso predictions (LSP) and calculating LSPs:
    d.coefs <- data.frame(LSP = rep(NA, nrow(d)))

    d.coefs$LSP <- as.numeric(as.matrix(d.subset[, 2:(ncol(d.subset) - 1)]) %*% matrix(coefs))

    d <- data.frame(G = d$G,
                    LSP = d.coefs$LSP,
                    Y = d$Y)

    # Covariances ----------------------------------------------------------------

    dm <- genoMeans(d)
    dm$G <- as.character(dm$G)

    if (CV == "CV1") {
      temp <- covFromSS(data = d, calc.Ve = TRUE, sepExp = sepExp)
      dm <- dm[match(train.set, dm$G),]
      rownames(dm) <- train.set
    } else if (CV == "CV2") {
      temp <- covFromSS(data = d[which(d$G %in% train.set),], calc.Ve = TRUE, sepExp = sepExp)
      dm <- dm[match(c(test.set, train.set), dm$G),]
      rownames(dm) <- c(test.set, train.set)
    }

    Vg <- temp$Vg
    Ve <- temp$Ve

    # Creating vector of LSP and focal trait heritabilities:
    H2vec <- diag(Vg) / (diag(Vg) + diag(Ve))

    # Determining number of replicates:
    n.rep.vector <- as.integer(table(d$G))
    n.rep <- (sum(n.rep.vector) - sum(n.rep.vector^2) / sum(n.rep.vector)) / (length(n.rep.vector) - 1)

    # BLUP Calculations ----------------------------------------------------------

    if (min(eigen(Vg)$values) < 0) {
      if (verbose) {
        cat("Genetic covariance matrix is not positive-definite. Using nearPD()...\n")
      }
      Vg <- as.matrix(Matrix::nearPD(x = Vg)$mat)
    }

    if (verbose) {
      cat("Making final test set predictions...\n\n")
    }

    if (CV == "CV1") {
      # Calculating focal trait BLUP for the training set:
      focalBLUP_train <- fast_o_gBLUP(Y = as.matrix(dm[, -1]),
                                      K = K,
                                      Vg = Vg,
                                      Ve = Ve / n.rep,
                                      train.set = train.set,
                                      targetName = focal)

      # Calculating focal trait BLUP for the test set:
      focalBLUP_test <- train2test(focalBLUP_train$focal_gBLUP, K = K,
                                   train.set = train.set, test.set = test.set)
    } else if (CV == "CV2") {
      # Calculating focal trait BLUP for the training set:
      BLUPs_train <- fast_o_gBLUP(Y = as.matrix(dm[train.set, -1]),
                                  K = K,
                                  Vg = Vg,
                                  Ve = Ve / n.rep,
                                  train.set = train.set,
                                  targetName = focal)

      # Calculating all BLUPs for the test set:
      BLUPs_test <- train2test(BLUPs_train$all_gBLUPs, K = K,
                               train.set = train.set, test.set = test.set)

      BLUP_Y_test <- BLUPs_test[, focal]
      BLUP_S_test <- BLUPs_test[, setdiff(colnames(BLUPs_test), focal)]
      Ktt <- K[test.set, test.set]
      Kto <- K[test.set, train.set]
      Koo <- K[train.set, train.set]
      Vc <- kronecker(Vg["LSP", "LSP"], solve(Ktt)) + kronecker(Ve["LSP", "LSP"] / n.rep, diag(dim(Ktt)[1]))

      # Final CV2 test set focal trait BLUP calculation following two-step approach (Runcie & Cheng, 2019):
      focalBLUP_test <- as.numeric(matrix(BLUP_Y_test) + kronecker(t(as.matrix(Vg["LSP", focal])), solve(Ktt)) %*%
                                     solve(Vc) %*% (matrix(as.matrix(dm[test.set, "LSP"])) - matrix(BLUP_S_test)))

      names(focalBLUP_test) <- test.set
    }
    return(list(preds = focalBLUP_test,
                coefs = coefs,
                Vg = Vg,
                Ve = Ve,
                H2s = H2vec,
                LSP = dm,
                AM.direct = as.numeric(H2vec[length(H2vec)]),
                AM.indirect = as.numeric(cov2cor(Vg)[1, 2]^2 * as.numeric(H2vec[1]))))
  }
  return(list(preds = preds))
}








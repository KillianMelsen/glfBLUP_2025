#' subset_CV
#'
#' A function that returns the best subset of factors using cross-validation and
#' calculation of BLUPs within the training set.
#'
#' @param d A dataframe containing the genotypes, and the mean of the factors scores and focal trait
#' for each genotype.
#' @param CV.percentile The top percentage of all possible subsets based on accuracy measure that must
#' be evaluated.
#' @param div Boolean indicating whether do divide the within training set prediction accuracies
#' by the number of factors underlying the predictions or not.
#' @param zxc Vector containing the names of the factors in all possible subsets.
#' @param zxc.scores Vector containing the accuracy measures of all subsets.
#' @param focal The name of the focal trait.
#' @param Vg The genetic covariance matrix of the factors and focal trait.
#' @param Ve The residual covariance matrix of the factors and focal trait.
#' @param n.rep The number of replicates.
#' @param K The kinship matrix.
#' @param do.parallel Boolean indicating whether to use parallelization or not.
#' @param CV Scenario: "CV1" or "CV2".
#' @param max.cores See max.cores in gfBLUP documentation.
#'
#' @return A character vector with the names of the factors in the best subset.
#'
#' @importFrom foreach %dopar%
#'
#' @keywords internal
subset_CV <- function(d, CV.percentile, div, zxc, zxc.scores, focal, Vg, Ve, n.rep, K,
                      do.parallel, CV, max.cores) {

  # Creating folds:
  ngeno <- length(as.integer(table(d$G)))
  fold <- rep(1:5, ceiling(ngeno / 5))[1:ngeno]
  shuffle <- sample(unique(d$G), ngeno)
  folds <- split(shuffle, as.factor(fold))

  # Store subsets that need to be evaluated:
  zxc.scores.top <- sort(zxc.scores, decreasing = TRUE)[1:(ceiling(length(zxc.scores) * CV.percentile))]
  zxc.top <- zxc[which(zxc.scores %in% zxc.scores.top)]

  # Check if parallelization is used and act accordingly:
  if (!(do.parallel)) {
    # Prepare storage for CV accuracy estimates:
    acc.CV <- rep(NA, length(zxc.top))

    for (set in 1:length(zxc.top)) {
      subset <- c(zxc.top[[set]], focal)
      mean.acc <- 0
      for (f in 1:length(folds)) {
        if (CV == "CV1") {
          focalBLUP_4folds <- fast_o_gBLUP(Y = as.matrix(d[!(d[, 1] %in% folds[[f]]), c(subset)]),
                                           K = K,
                                           Vg = Vg[subset, subset],
                                           Ve = Ve[subset, subset] / n.rep,
                                           train.set = rownames(as.matrix(d[!(d[, 1] %in% folds[[f]]), -1])),
                                           targetName = focal)

          focalBLUP_1fold <- train2test(focalBLUP_4folds$focal_gBLUP, K = K,
                                        train.set = rownames(as.matrix(d[!(d[, 1] %in% folds[[f]]), -1])),
                                        test.set = rownames(as.matrix(d[d[, 1] %in% folds[[f]], -1])))

          mean.acc <- mean.acc + cor(focalBLUP_1fold, d[d[, 1] %in% folds[[f]], focal])
        } else if (CV == "CV2") {
          train.set.ss <- rownames(as.matrix(d[!(d[, 1] %in% folds[[f]]), -1]))
          test.set.ss <- rownames(as.matrix(d[d[, 1] %in% folds[[f]], -1]))

          BLUPs_4folds <- fast_o_gBLUP(Y = as.matrix(d[!(d[, 1] %in% folds[[f]]), c(subset)]),
                                       K = K,
                                       Vg = Vg[subset, subset],
                                       Ve = Ve[subset, subset] / n.rep,
                                       train.set = train.set.ss,
                                       targetName = focal)

          BLUPs_1fold <- train2test(BLUPs_4folds$all_gBLUPs, K = K,
                                    train.set = train.set.ss,
                                    test.set = test.set.ss)

          BLUP_Y_test <- BLUPs_1fold[, focal]
          BLUP_S_test <- BLUPs_1fold[, setdiff(colnames(BLUPs_1fold), focal)]
          Ktt <- K[test.set.ss, test.set.ss]
          Kto <- K[test.set.ss, train.set.ss]
          Koo <- K[train.set.ss, train.set.ss]
          factors <- setdiff(subset, focal)
          Vc <- kronecker(Vg[factors, factors], solve(Ktt)) + kronecker(Ve[factors, factors] / n.rep, diag(dim(Ktt)[1]))

          # Final CV2 test set focal trait BLUP calculation following two-step approach (Runcie & Cheng, 2019):
          focalBLUP_test <- as.numeric(matrix(BLUP_Y_test) + kronecker(t(as.matrix(Vg[factors, focal])), solve(Ktt)) %*%
                                         solve(Vc) %*%
                                         (matrix(as.matrix(d[d[, 1] %in% folds[[f]], factors])) - matrix(BLUP_S_test)))

          names(focalBLUP_test) <- test.set.ss
          mean.acc <- mean.acc + cor(focalBLUP_test, d[d[, 1] %in% folds[[f]], focal])
        }
      }
      if (div) {
        acc.CV[set] <- mean.acc / length(folds) / length(zxc.top[[set]])
      } else {
        acc.CV[set] <- mean.acc / length(folds)
      }
      names(acc.CV)[set] <- paste(zxc.top[[set]], collapse = " ")
    }
  } else if (do.parallel) {
    if (is.null(max.cores)) {
      cores <- parallel::detectCores() - 2
    } else {
      cores <- min(parallel::detectCores() - 2, max.cores)
    }
    doParallel::registerDoParallel(cores = cores)
    cat("Parallelizing the subset selection cross-validation process.", cores, "cores used...\n")

    acc.CV <- foreach::foreach(set = 1:length(zxc.top), .combine = c, .packages = c("gfBLUP")) %dopar% {
      subset <- c(zxc.top[[set]], focal)
      mean.acc <- 0
      for (f in 1:length(folds)) {
        if (CV == "CV1") {
          focalBLUP_4folds <- gfBLUPold:::fast_o_gBLUP(Y = as.matrix(d[!(d[, 1] %in% folds[[f]]), c(subset)]),
                                                    K = K,
                                                    Vg = Vg[subset, subset],
                                                    Ve = Ve[subset, subset] / n.rep,
                                                    train.set = rownames(as.matrix(d[!(d[, 1] %in% folds[[f]]), -1])),
                                                    targetName = focal)

          focalBLUP_1fold <- gfBLUPold:::train2test(focalBLUP_4folds$focal_gBLUP, K = K,
                                                 train.set = rownames(as.matrix(d[!(d[, 1] %in% folds[[f]]), -1])),
                                                 test.set = rownames(as.matrix(d[d[, 1] %in% folds[[f]], -1])))

          mean.acc <- mean.acc + cor(focalBLUP_1fold, d[d[, 1] %in% folds[[f]], focal])
        } else if (CV == "CV2") {
          train.set.ss <- rownames(as.matrix(d[!(d[, 1] %in% folds[[f]]), -1]))
          test.set.ss <- rownames(as.matrix(d[d[, 1] %in% folds[[f]], -1]))

          BLUPs_4folds <- fast_o_gBLUP(Y = as.matrix(d[!(d[, 1] %in% folds[[f]]), c(subset)]),
                                       K = K,
                                       Vg = Vg[subset, subset],
                                       Ve = Ve[subset, subset] / n.rep,
                                       train.set = train.set.ss,
                                       targetName = focal)

          BLUPs_1fold <- train2test(BLUPs_4folds$all_gBLUPs, K = K,
                                    train.set = train.set.ss,
                                    test.set = test.set.ss)

          BLUP_Y_test <- BLUPs_1fold[, focal]
          BLUP_S_test <- BLUPs_1fold[, setdiff(colnames(BLUPs_1fold), focal)]
          Ktt <- K[test.set.ss, test.set.ss]
          Kto <- K[test.set.ss, train.set.ss]
          Koo <- K[train.set.ss, train.set.ss]
          factors <- setdiff(subset, focal)
          Vc <- kronecker(Vg[factors, factors], solve(Ktt)) + kronecker(Ve[factors, factors] / n.rep, diag(dim(Ktt)[1]))

          # Final CV2 test set focal trait BLUP calculation following two-step approach (Runcie & Cheng, 2019):
          focalBLUP_test <- as.numeric(matrix(BLUP_Y_test) + kronecker(t(as.matrix(Vg[factors, focal])), solve(Ktt)) %*%
                                         solve(Vc) %*%
                                         (matrix(as.matrix(d[d[, 1] %in% folds[[f]], factors])) - matrix(BLUP_S_test)))

          names(focalBLUP_test) <- test.set.ss
          mean.acc <- mean.acc + cor(focalBLUP_test, d[d[, 1] %in% folds[[f]], focal])
        }
      }
      if (div) {
        mean.acc <- mean.acc / length(folds) / length(zxc.top[[set]])
      } else {
        mean.acc <- mean.acc / length(folds)
      }
      names(mean.acc) <- paste(zxc.top[[set]], collapse = " ")
      return(mean.acc)
    }
    doParallel::stopImplicitCluster()
  }
  F.select <- zxc.top[[which(acc.CV == max(acc.CV))]]
  return(F.select)
}

#' regPhenCor_corlw
#'
#' Helper function for regPhenCor that calculates the Ledoit-Wolf type regularized
#' phenotypic correlation matrix based on the sample phenotypic correlation matrix, a penalty,
#' and a target matrix.
#'
#' @param R The sample phenotypic correlation matrix from regPhenCor_kcvl.
#' @param penalty The regularization penalty that must be optimized.
#' @param targetmatrix A character specifying what target matrix to use. Leave on \code{"identity"} for now.
#'
#' @return A regularized phenotypic correlation matrix.
#'
#' @keywords internal
regPhenCor_corlw <- function(R, penalty, targetmatrix) {
  if (class(targetmatrix)[1] != "matrix") {
    if (targetmatrix == "identity") {
      return((1 - penalty) * R + penalty * diag(dim(R)[1]))
    } else if (targetmatrix == "nonsense") {
      return((1 - penalty) * R + penalty * matrix(data = 1, nrow = dim(R)[1], ncol = dim(R)[1]))
    } else {
      stop("No target matrix specified!")
    }
  } else {
    return((1 - penalty) * R + penalty * targetmatrix)
  }
}

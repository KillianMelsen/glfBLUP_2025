#' regGenCor_corlw
#'
#' Helper function for regGenCor that calculates the Ledoit-Wolf type regularized
#' genetic correlation matrix based on the sample genetic correlation matrix, a penalty,
#' and a target matrix.
#'
#' @param R The sample genetic correlation matrix from regGenCor_kcvl.
#' @param penalty The regularization penalty that must be optimized.
#' @param targetmatrix A character specifying what target matrix to use. Leave on \code{"identity"} for now.
#'
#' @return A regularized genetic correlation matrix.
#'
#' @keywords internal
regGenCor_corlw <- function(R, penalty, targetmatrix) {
  if (class(targetmatrix)[1] != "matrix") {
    if (targetmatrix == "identity") {
      return((1 - penalty) * R + penalty * diag(dim(R)[1]))
    } else if (targetmatrix == "nonsense") {
      return((1 - penalty) * R + penalty * matrix(data = 1, nrow = dim(R)[1], ncol = dim(R)[1]))
    } else {
      stop("No target matrix specified!")
    }
  } else {
    return((1 - penalty) * R + penalty * targetmatrix)
  }
}

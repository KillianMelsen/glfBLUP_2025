#' regPhenCor_kcvl
#'
#' A helper function for regPhenCor that calculates the mean cross-validated
#' negative log-likelihood that is used to find the optimal penalty.
#'
#' @param penalty The penalty that must me optimized.
#' @param X The data matrix passed from regPhenCor.
#' @param folds Number of folds passed from regPhenCor.
#' @param targetmatrix The regularization target as passed from regPhenCor.
#' @param mu.geno Dataframe containing the genotype means. This is calculated only
#' once in regPhenCor.
#' @param n.rep Mean number of replicates per genotype. Also calculated in regPhenCor.
#' @param do.parallel boolean indicating whether to use parallelization or not.
#' @param use_nearPD use_nearPD Boolean indicating whether to use nearPD calls to enforce PDness
#' of the calculated genetic covariance matrix.
#' @param use_ginv Boolean indicating whether to calculate the generalized inverse
#' if R is singular.
#'
#' @return The mean cross-validated negative log-likelihood.
#'
#' @importFrom foreach %dopar%
#' @importFrom stats cov
#'
#' @keywords internal
regPhenCor_kcvl <- function(penalty, X, folds, targetmatrix, mu.geno, n.rep, do.parallel, use_nearPD, use_ginv) {
  if (!(do.parallel)) {
    cvLL <- 0
    for (f in 1:length(folds)){
      # # Make R dataframe with genotype means (4/5 folds):
      # R_means <- mu.geno[!(mu.geno$G %in% folds[[f]]), , drop = FALSE]
      # Vp.R <- cov(R_means[, -1])
      #
      # Vp.R <- (Vp.R + t(Vp.R)) / 2
      # if (min(eigen(Vp.R)$values) < 0) {
      #   Vp.R <- as.matrix(Matrix::nearPD(Vp.R, keepDiag = FALSE)$mat)
      # }
      # temp <- which(diag(Vp.R) < 0)
      # if (length(temp) > 0) {
      #   Vp.R[temp, ] <- 0
      #   Vp.R[, temp] <- 0
      #   if (min(eigen(Vp.R)$values) < 0) {
      #     Vp.R <- as.matrix(Matrix::nearPD(Vp.R, keepDiag = TRUE)$mat)
      #   }
      # }

      # Make dataframe for 4/5 folds:
      R_dataframe <- as.data.frame(X)[!(X[,1] %in% folds[[f]]), , drop = FALSE]
      R_dataframe$G <- factor(as.character(R_dataframe$G))
      secondaries <- names(R_dataframe)[2:length(names(R_dataframe))]
      R_dataframe[secondaries] <- lapply(R_dataframe[secondaries], as.numeric)

      # Calculating R:
      covs <- covFromSS(data = R_dataframe, mu.geno = mu.geno, n.rep = n.rep, calc.Ve = TRUE, use_nearPD = use_nearPD)
      Vg.R <- covs$Vg
      Ve.R <- covs$Ve
      Vp.R <- Vg.R + Ve.R
      R <- cov2cor(Vp.R)

      # # Make S dataframe with genotype means (1/5 folds):
      # S_means <- mu.geno[mu.geno$G %in% folds[[f]], , drop = FALSE]
      # Vp.S <- cov(S_means[, -1])
      #
      # Vp.S <- (Vp.S + t(Vp.S)) / 2
      # if (min(eigen(Vp.S)$values) < 0) {
      #   Vp.S <- as.matrix(Matrix::nearPD(Vp.S, keepDiag = FALSE)$mat)
      # }
      # temp <- which(diag(Vp.S) < 0)
      # if (length(temp) > 0) {
      #   Vp.S[temp, ] <- 0
      #   Vp.S[, temp] <- 0
      #   if (min(eigen(Vp.S)$values) < 0) {
      #     Vp.S <- as.matrix(Matrix::nearPD(Vp.S, keepDiag = TRUE)$mat)
      #   }
      # }

      # Making dataframe for the left out fold:
      S_dataframe <- as.data.frame(X)[X[,1] %in% folds[[f]], , drop = FALSE]
      S_dataframe$G <- factor(as.character(S_dataframe$G))
      secondaries <- names(S_dataframe)[2:length(names(S_dataframe))]
      S_dataframe[secondaries] <- lapply(S_dataframe[secondaries], as.numeric)

      # Calculating S:
      covs <- covFromSS(data = S_dataframe, mu.geno = mu.geno, n.rep = n.rep, calc.Ve = TRUE, use_nearPD = use_nearPD)
      Vg.S <- covs$Vg
      Ve.S <- covs$Ve
      Vp.S <- Vg.S + Ve.S
      S <- cov2cor(Vp.S)

      nf   <- dim(as.data.frame(X)[X[,1] %in% folds[[f]], , drop = FALSE])[1]
      cvLL <- cvLL + nf * regPhenCor_ll(S, regPhenCor_corlw(R, penalty, targetmatrix), use_ginv = use_ginv)
    }
    return(cvLL/length(folds))
  } else if (do.parallel) {
    ### PARALLELIZATION
    cvLL <- foreach::foreach(f = 1:length(folds), .combine = "+", .packages = c("gfBLUPold")) %dopar% {
      # # Make R dataframe with genotype means (4/5 folds):
      # R_means <- mu.geno[!(mu.geno$G %in% folds[[f]]), , drop = FALSE]
      # Vp.R <- cov(R_means[, -1])

      # Make dataframe for 4/5 folds:
      R_dataframe <- as.data.frame(X)[!(X[,1] %in% folds[[f]]), , drop = FALSE]
      R_dataframe$G <- factor(as.character(R_dataframe$G))
      secondaries <- names(R_dataframe)[2:length(names(R_dataframe))]
      R_dataframe[secondaries] <- lapply(R_dataframe[secondaries], as.numeric)

      # Calculating R:
      covs <- gfBLUPold:::covFromSS(data = R_dataframe, mu.geno = mu.geno, n.rep = n.rep, calc.Ve = TRUE, use_nearPD = use_nearPD)
      Vg.R <- covs$Vg
      Ve.R <- covs$Ve
      Vp.R <- Vg.R + Ve.R
      R <- cov2cor(Vp.R)

      # # Make S dataframe with genotype means (1/5 folds):
      # S_means <- mu.geno[mu.geno$G %in% folds[[f]], , drop = FALSE]
      # Vp.S <- cov(S_means[, -1])

      # Making dataframe for the left out fold:
      S_dataframe <- as.data.frame(X)[X[,1] %in% folds[[f]], , drop = FALSE]
      S_dataframe$G <- factor(as.character(S_dataframe$G))
      secondaries <- names(S_dataframe)[2:length(names(S_dataframe))]
      S_dataframe[secondaries] <- lapply(S_dataframe[secondaries], as.numeric)

      # Calculating S:
      covs <- gfBLUPold:::covFromSS(data = S_dataframe, mu.geno = mu.geno, n.rep = n.rep, calc.Ve = TRUE, use_nearPD = use_nearPD)
      Vg.S <- covs$Vg
      Ve.S <- covs$Ve
      Vp.S <- Vg.S + Ve.S
      S <- cov2cor(Vp.S)

      nf   <- dim(as.data.frame(X)[X[,1] %in% folds[[f]], , drop = FALSE])[1]
      LL <- nf * gfBLUPold:::regPhenCor_ll(S, gfBLUPold:::regPhenCor_corlw(R, penalty, targetmatrix), use_ginv = use_ginv)
      return(LL)
    }
    return(cvLL/length(folds))
  }
}

#' rmvDAG_h2
#'
#' Simulates factorable data.
#'
#' @param ng Number of genotypes.
#' @param r Number of replicates.
#' @param gsem gsem object.
#' @param M ng x n_snp marker matrix.
#' @param simFromVgVe Boolean indicating whether to simulate directly from gsem$Vg and gsem$Ve
#' @param K Kinship
#'
#' @return q
#'
#' @keywords internal
rmvDAG_h2 <- function (ng, r, gsem, M = NULL, simFromVgVe = FALSE, K = NULL) {
  # Generate multi-variate normal data, for a given genetic SEM
  # ng : number of genotypes
  # r : number of replicates
  # gsem : a genetic sem object, containing the dag, ....

  N <- ng * r # number of genotypes times number of replicates

  stopifnot(methods::is(gsem$dag, "graph"))

  p <- length(graph::nodes(gsem$dag))

  weightMatrix  <- pcalg::wgtMatrix(gsem$dag)
  weightMatrix2 <- t(gsem$Lambda)

  nonZeros <- which(weightMatrix != 0, arr.ind = TRUE)

  if (nrow(nonZeros) > 0) {
    if (any(nonZeros[, 1] - nonZeros[, 2] < 0) || any(diag(weightMatrix) !=
                                                      0))
      stop("Input DAG must be topologically ordered!")
  }

  errMat <- matrix(rep(0,N * p), nrow = N)

  if (simFromVgVe == FALSE) {
    for (i in 1:N) {
      errMat[i, ] <- errMat[i, ] + MASS::mvrnorm(n=1, mu=rep(0,p), Sigma=gsem$envCovMatrix)
    }
  } else if (simFromVgVe & class(K)[1] == "matrix") {
    errMat <- simulate_multi_trait_data(K = diag(1, N, N), Vg = gsem$Ve)
  }

  G <- matrix(0, ng, p)

  if (simFromVgVe == FALSE) {
    for (s in 1:ncol(M)) {
      Us <- matrix(MASS::mvrnorm(n=1, mu=rep(0,p), Sigma=gsem$genCovMatrix/ncol(M)), ncol=p)
      G <- G + matrix(M[,s]) %*% Us
    }
  } else if (simFromVgVe & class(K)[1] == "matrix") {
    G <- simulate_multi_trait_data(K = K, Vg = gsem$Vg)
  } else {
    stop("Either simFromVgVe is not FALSE/TRUE or K is not a matrix")
  }
  X <- errMat + kronecker(G, matrix(rep(1,r), ncol=1))

  #rewrite the following lines, in case the causal relations are to be nonlinear
  if (simFromVgVe == FALSE) {
    if (sum(weightMatrix) > 0) {
      for (j in 2:p) {
        ij <- 1:(j - 1)
        X[, j] <- X[, j] + X[, ij, drop = FALSE] %*% weightMatrix2[j,ij]
      }
    }
  }
  gen <- rep(paste0('g', 1:ng), each = r)
  gen_unique <- paste0("g", 1:ng)
  rownames(G) <- gen_unique
  fulldata <- data.frame(G=gen, X)
  colnames(fulldata)[-1] <- graph::nodes(gsem$dag)

  fulldata <- data.frame(fulldata, block = factor(rep(1:r,ng)))


  return(list(fulldata = fulldata, Gmatrix=G))
}

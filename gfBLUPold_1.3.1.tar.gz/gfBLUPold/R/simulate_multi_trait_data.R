#' simulate_multi_trait_data
#'
#' Simulates multitrait data.
#'
#' @param K Kinship matrix.
#' @param Vg Genetic covariance matrix.
#'
#' @return q
#'
#' @importFrom stats rnorm
#'
#' @keywords internal
simulate_multi_trait_data <- function(K,Vg) {
  n  <- nrow(K)
  p  <- ncol(Vg)
  S  <- MatrixRoot(K)
  V  <- MatrixRoot(Vg)
  Z  <- matrix(rnorm(n=n*p),ncol=p)
  Y  <- S %*% Z %*% V
  return(Y)
}

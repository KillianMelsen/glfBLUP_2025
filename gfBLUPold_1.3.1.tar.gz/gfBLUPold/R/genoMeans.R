#' genoMeans
#'
#' Calculates the mean trait value for each genoype based on data containing
#' replicates.
#'
#' @param data A dataframe where the first column contains the genotypes. All
#' other columns must contain secondary trait measurements. Must contain genotype
#' replicates!
#'
#' @return A dataframe containing per-genotype means.
#'
#' @keywords internal
genoMeans <- function(data) {
  data.means <- aggregate(data[, 2:ncol(data)], list(data[, 1]), mean)
  names(data.means)[1] <- names(data)[1]
  data.means$G <- as.character(data.means$G)
  return(data.means)
}

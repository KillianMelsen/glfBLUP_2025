#' Genetic factor best linear unbiased prediction
#'
#' \code{gfBLUP} makes multi-trait genomic predictions using a factor-analytic dimension reduction
#' of the secondary traits.
#'
#' @param d A dataframe containing the genotype, a set of secondary traits, and a focal trait. Must contain replicates.
#' @param geno An optional argument specifying the column containing the genotypes. The default assumes the first column
#' of \code{d} contains the genotypes.
#' @param focal An optional argument specifying the column containing the focal trait. The default assumes the last column
#' of \code{d} contains the focal trait.
#' @param sec An optional argument specifying the column indices of the columns in \code{d} that contain the secondary traits.
#' The default assumes all columns of \code{d} except the first and last contain the secondary traits.
#' @param K The kinship matrix of training and test genotypes.
#' @param subset.select The subset selection method. \code{subset.select = c("leaps", "AC", "CV", "CVdiv")}.
#' @param CV.percentile The top percentage of subsets that should be evaluated using cross validation for the \code{"CV"}
#' and \code{"CVdiv"} subset selection methods.
#' @param mf.max Optional argument specifying the number of factors to be used in the factor model. The default uses
#' Marchenko-Pastur bounds to the determine the factor number.
#' @param low Numeric specifing the minimum value for the uniquenesses. Best left at default of \code{0.1}.
#' @param use.promax Boolean specifying whether to use a promax rotation or not. If set to \code{FALSE} a varimax rotation is
#' used.
#' @param criterion.override Boolean specifying whether to override the accuracy criterion if none of the subsets has a high
#' enough accuracy measure. Only applies to the \code{"AC"} subset selection method.
#' @param reg.target Argument specifying the regularization target to be used. Default is \code{"identity"}. \code{"hyperspectral"} might
#' be a future option. Can also be a matrix.
#' @param reg.penalty Optional argument in case a user-specified regularization penalty must be used. If left at default value of NULL
#' the optimal penalty will be determined using 5-fold CV. If specifying a penalty, note that it must be between 0 and 1.
#' @param CV CV scenario. Leave at default of \code{"CV1"} for now.
#' @param CV2.method Character specifying the way to calculate the CV2 BLUPs for the test set.
#' \code{CV2.method = c("Runcie", "Bader", "RuncieFast")}.
#' @param verbose Display information or not.
#' @param do.parallel Use paralellization or not.
#' @param use_means Boolean indicating whether to calculate Vg using the sums of squares or
#' by using the function cov on the matrix of genotypic means.
#' @param sepExp IMPORTANT! Boolean that must be set to TRUE if the focal trait was measured
#' in a different experiment/on different plants than the secondary traits. If that is the case,
#' the residual covariances between the focal and secondary traits, in the MSE matrix in the
#' covFromSS function, are set to 0.
#' @param t.RF Threshold value for redundancy filtering. Defaults to \code{0.95}.
#' @param max.cores Maximum number of cores to be used during CV subset selection. NULL by default, which results in n-2 cores being
#' used. Can be useful if using too many cores with large datasets results in memory issues.
#'
#' @return A list containing the test set predictions, the optimal regularization penalty, a character vector containing the
#' names of the selected factors, the factor loadings, and the factor uniquenesses.
#'
#' @examples
#' ## Import the included example dataset:
#' example <- gfBLUPold::simExampleData
#'
#' ## Run gfBLUP:
#' results <- gfBLUP(d = example$d, K = example$K, subset.select = "leaps")
#'
#' ## Calculate prediction accuracy:
#' cor(results$preds, example$pred.target)
#'
#' @importFrom stats aggregate cor cov2cor na.omit optim
#'
#' @export
#'
gfBLUP <- function(d, geno = names(d)[1], focal = names(d)[ncol(d)], sec = 2:(length(names(d)) - 1),
                   K, subset.select = "CV", CV.percentile = 0.2, mf.max = NULL, low = 0.1,
                   use.promax = FALSE, criterion.override = FALSE, reg.target = "identity",
                   reg.penalty = NULL, CV = "CV1", CV2.method = "Runcie", verbose = TRUE,
                   do.parallel = FALSE, use_means = FALSE, sepExp = FALSE, t.RF = 0.95, max.cores = NULL) {

  #############################################################################
  ### 1. Argument checking ####################################################
  #############################################################################

  stopifnot(class(d) == "data.frame",
            class(geno) == "character",
            class(focal) == "character",
            class(sec) %in% c("integer", "numeric"),
            class(K) == c("matrix", "array"),
            subset.select %in% c("AC", "CV", "CVdiv", "leaps"),
            class(mf.max) %in% c("NULL", "numeric"),
            class(low) == "numeric",
            class(use.promax) == "logical",
            class(criterion.override) == "logical",
            reg.target %in% c("identity", "hyperspectral") | class(reg.target)[1] == "matrix",
            CV %in% c("CV1", "CV2"),
            class(verbose) == "logical",
            class(do.parallel) == "logical",
            CV2.method %in% c("Runcie", "Bader", "RuncieFast"),
            class(max.cores) %in% c("numeric", "NULL"))

  #############################################################################
  ### 2. Reformatting data and collecting necesarry information ###############
  #############################################################################

  # Making sure max.cores is an integer if specified:
  if (!(is.null(max.cores))) {
    max.cores <- as.integer(max.cores)
  }

  # Reformat input data so it only includes genotype, secondary traits, and the
  # focal trait:
  d <- cbind(d[, geno], d[, sec], d[, focal])
  names(d)[1] <- "G"
  names(d)[ncol(d)] <- focal

  # Determine the number of traits (secondary + focal):
  p <- ncol(d) - 1

  # Storing training and testing genotypes:
  train.set <- as.character(unique(d$G[!is.na(d[, focal])]))
  test.set <- as.character(setdiff(unique(d$G), train.set))

  # Setting all trait values or just the focal trait values to NA for test set
  # depending on the CV-scenario:
  if (CV == "CV1") {
    d[d$G %in% test.set, setdiff(names(d), "G")] <- NA
  }

  # Changing genotype to factor and dropping any levels if necessary:
  d$G <- as.factor(d$G)
  d <- droplevels(d)

  #############################################################################
  ### 3. Redundancy filtering #################################################
  #############################################################################

  if (verbose) {
    cat("Starting redundancy filtering...\n")
  }

  # Retrieve genetic covariance matrix for secondary traits for redundancy
  # filtering:
  if (CV == "CV1") {
    Vg.all.sec <- covFromSS(data = d[1:p], use_nearPD = TRUE, use_means = use_means)$Vg
  } else if (CV == "CV2") {
    # For now let's use just the training set, even in CV2...
    Vg.all.sec <- covFromSS(data = d[which(d$G %in% train.set), 1:p], use_nearPD = TRUE,
                            use_means = use_means)$Vg
  }

  # Redundancy filtering the genetic correlation matrix of secondary traits:
  Rg.filter.sec <- FMradio::RF(cov2cor(Vg.all.sec), t = t.RF)

  if (verbose) {
    cat(dim(Rg.filter.sec)[1], "out of", dim(Vg.all.sec)[1],
        "secondary traits remain after redundancy filtering...\n")
  }

  # Subsetting data after redundancy filtering:
  d.subset <- as.data.frame(FMradio::subSet(as.matrix(d[, 2:p]), Rg.filter.sec))

  # Adding back genotype and focal trait:
  d.subset <- as.data.frame(cbind(d$G, d.subset, d[, focal]))
  names(d.subset)[1] <- "G"
  names(d.subset)[ncol(d.subset)] <- focal

  # Removing rows with missing data (test genotypes) for regularization:
  d.subset.train <- na.omit(d.subset)
  d.subset.train <- droplevels(d.subset.train)

  # Subsetting user specified regularization target (if specified):
  if (class(reg.target)[1] == "matrix") {
    remove <- rownames(reg.target)[!(rownames(reg.target) %in% rownames(Rg.filter.sec))]
    reg.target <- reg.target[setdiff(rownames(reg.target), remove),
                             setdiff(colnames(reg.target), remove)]

  }

  if (verbose) {
    cat("Dimensions of redundancy filtered training subset are ", dim(d.subset.train)[1],
        " by ", dim(d.subset.train)[2], "...\n\n", sep = "")
  }

  #############################################################################
  ### 4. Regularizing #########################################################
  #############################################################################

  # Regularizing genetic correlation matrix of remaining secondary traits:
  if (verbose) {
    cat("Regularizing genetic correlation matrix of remaining secondary traits...\n")
    if (class(reg.target)[1] == "matrix") {
      cat("Using user-specified regularization target...\n")
    } else {
      cat("Using", reg.target, "regularization target...\n")
    }
  }

  # Due to line 134-136 (subsetting to training set) regularization is done using only the training set, even in CV2:
  OPT <- regGenCor(X = as.matrix(d.subset.train[, 1:(dim(Rg.filter.sec)[1] + 1)]),
                   fold = 5, targetmatrix = reg.target, verbose = verbose,
                   do.parallel = do.parallel, use_nearPD = TRUE, use_ginv = FALSE,
                   reg.penalty = reg.penalty, use_means = use_means)

  if (verbose) {
    cat("Optimal penalty value set at: ", OPT$optPen, "...\n", sep = "")
  }
  Rg.reg <- OPT$optCor
  KMO <- FMradio::SA(Rg.reg)

  if (verbose) {
    cat("KMO measure of", KMO$KMO, "\n\n")
  }

  # Retrieving variances:
  S <- diag(OPT$RFsubset_cov)

  # Reconverting regularized genetic correlation matrix to covariance matrix:
  Vg.reg <- outer(sqrt(S), sqrt(S)) * Rg.reg

  #############################################################################
  ### 5. Fitting factor model and obtaining scores ############################
  #############################################################################

  # Calculating Marchenko-Pastur bound for the number of factors to be used:
  ev.thr <- (1 + sqrt(ncol(Vg.reg) / length(train.set)))^2

  # Factor number determination (if not specified):
  if (is.null(mf.max)) {
    mf.max <- sum(eigen(cov2cor(Vg.reg))$values > ev.thr)
    if (verbose) {
      cat("M-P bound is ", ev.thr, "...\n", sep = "")
      cat("Fitting factor model with", mf.max, "factors...\n\n")
    }
  } else {
    if (verbose) {
      cat("Number of factors is fixed at", mf.max, "\n\n")
    }
  }

  # Fitting factor model:
  fito <- mlFA2(R = Vg.reg, m = mf.max, low = low)

  if (use.promax) {
    fito$Loadings <- stats::promax(fito$Loadings)$loadings
  }

  # Preparing dataframe for factor scores:
  dfact <- data.frame(matrix(NA, nrow(d), mf.max))
  names(dfact) <- paste0("F", 1:mf.max)

  # Filling factor score dataframe and binding to original dataframe:
  # Note that in CV2 the factor model was fit using only the training set, but here factor scores are calculated
  # for the test set as well (Because the secondary traits were never set to NA for the test set).
  dfact <- FMradio::facScore(as.matrix(d[, colnames(Vg.reg)]),
                             fito$Loadings, fito$Uniqueness)
  names(dfact) <- paste0("F", 1:mf.max)
  d <- cbind(d, dfact)

  #############################################################################
  ### 6. Preparing for subset selection and BLUP calculations #################
  #############################################################################

  # Creating final dataframe with arithmetic means:
  if (CV == "CV1") {
    dm <- genoMeans(data = d[which(d$G %in% train.set), c("G", names(dfact), focal)])
    dm$G <- as.character(dm$G)
    dm <- dm[match(train.set, dm$G),]
    rownames(dm) <- train.set
  } else if (CV == "CV2") {
    dm <- genoMeans(data = d[, c("G", names(dfact), focal)])
    dm$G <- as.character(dm$G)
    dm <- dm[match(c(test.set, train.set), dm$G),]
    rownames(dm) <- c(test.set, train.set)
  }


  # Calculating Vg and Ve to be used in subset selection and gBLUP calculations:
  # Again, in CV2 Vg and Ve are calculated using only the training set.
  if (CV == "CV1") {
    temp <- covFromSS(data = d[, c("G", names(dfact), focal)],
                      calc.Ve = TRUE, use_nearPD = TRUE, use_means = FALSE, sepExp = sepExp)
  } else if (CV == "CV2") {
    temp <- covFromSS(data = d[which(d$G %in% train.set), c("G", names(dfact), focal)],
                      calc.Ve = TRUE, use_nearPD = TRUE, use_means = FALSE, sepExp = sepExp)
  }
  Vg <- temp$Vg
  Ve <- temp$Ve

  # Creating vector of factor and focal trait heritabilities:
  H2vec <- diag(Vg) / (diag(Vg) + diag(Ve))

  # Storing names of factors and focal trait:
  t.names  <- c(names(dfact), focal)

  # Determining number of replicates:
  n.rep.vector <- as.integer(table(d$G))
  n.rep <- (sum(n.rep.vector) - sum(n.rep.vector^2) / sum(n.rep.vector)) / (length(n.rep.vector) - 1)

  #############################################################################
  ### 7. Subset selection #####################################################
  #############################################################################

  if (verbose) {
    cat("Starting subset selection using", subset.select, "method...\n")
    if (subset.select %in% c("CV", "CVdiv")) {
      cat("Evaluating top ", (CV.percentile * 100), "% of subsets based on accuracy measure...\n", sep = "")
    }
  }

  if (subset.select == "leaps") {
    F.select <- subset_leaps(d = dm[which(dm$G %in% train.set),], factors = names(dfact), focal = focal)

  } else {
    temp <- acc_measures(factors = names(dfact), Vg = Vg, Ve = Ve,
                         focal = focal, H2.focal = H2vec[ncol(Vg)])

    if (subset.select == "AC") {
      F.select <- subset_AC(zxc = temp$zxc, zxc.scores = temp$zxc.scores, criterion = temp$criterion,
                            criterion.override = criterion.override, verbose = verbose)

    } else if (subset.select == "CV") {
      if (verbose) {
        cat("Evaluating top ", ceiling(length(temp$zxc.scores) * CV.percentile), " subsets out of ",
            length(temp$zxc.scores), "\n\n", sep = "")
      }
      if (CV == "CV1") {
        F.select <- subset_CV(d = dm, CV.percentile = CV.percentile, div = FALSE,
                              zxc = temp$zxc, zxc.scores = temp$zxc.scores, focal = focal,
                              Vg = Vg, Ve = Ve, n.rep = n.rep, K = K, do.parallel = do.parallel, CV = "CV1",
                              max.cores = max.cores)
      } else if (CV == "CV2") {
        F.select <- subset_CV(d = dm[which(dm$G %in% train.set),], CV.percentile = CV.percentile, div = FALSE,
                              zxc = temp$zxc, zxc.scores = temp$zxc.scores, focal = focal,
                              Vg = Vg, Ve = Ve, n.rep = n.rep, K = K, do.parallel = do.parallel, CV = "CV2",
                              max.cores = max.cores)
      }
    } else if (subset.select == "CVdiv") {
      if (verbose) {
        cat("Evaluating top ", ceiling(length(temp$zxc.scores) * CV.percentile), " subsets out of ",
            length(temp$zxc.scores), "\n\n", sep = "")
      }
      F.select <- subset_CV(d = dm, CV.percentile = CV.percentile, div = TRUE,
                            zxc = temp$zxc, zxc.scores = temp$zxc.scores, focal = focal,
                            Vg = Vg, Ve = Ve, n.rep = n.rep, K = K, do.parallel = do.parallel)
    }
  }

  if (verbose) {
    cat("Selected factors using ", subset.select, " method are: ",
        paste(F.select, collapse = " "), "...\n\n", sep = "")
  }


  #############################################################################
  ### 8. BLUP calculations ####################################################
  #############################################################################

  # Creating appropriate subsets based on subset selection:
  dm.subset <- dm[, c("G", F.select, focal)]
  Vg.subset <- Vg[c(F.select, focal), c(F.select, focal)]
  Ve.subset <- Ve[c(F.select, focal), c(F.select, focal)]

  if (min(eigen(Vg.subset)$values) < 0) {
    if (verbose) {
      cat("Subsetted genetic covariance matrix is not positive-definite. Using nearPD()...\n")
    }
    Vg.subset <- as.matrix(Matrix::nearPD(x = Vg.subset)$mat)
  }

  if (verbose) {
    cat("Making final test set predictions...\n\n")
  }

  if (CV == "CV1") {
    # Calculating BLUPs for the training set:
    BLUPs_train <- fast_o_gBLUP(Y = as.matrix(dm.subset[, -1]),
                                K = K,
                                Vg = Vg.subset,
                                Ve = Ve.subset / n.rep,
                                train.set = train.set,
                                targetName = focal)

    # Calculating focal trait BLUP for the test set:
    focalBLUP_test <- train2test(BLUPs_train$focal_gBLUP, K = K,
                                 train.set = train.set, test.set = test.set)
  } else if (CV == "CV2") {
    if (CV2.method == "Runcie") {
      # Calculating BLUPs for the training set:
      BLUPs_train <- fast_o_gBLUP(Y = as.matrix(dm.subset[train.set, -1]),
                                  K = K,
                                  Vg = Vg.subset,
                                  Ve = Ve.subset / n.rep,
                                  train.set = train.set,
                                  targetName = focal)

      # Calculating all BLUPs for the test set:
      BLUPs_test <- train2test(BLUPs_train$all_gBLUPs, K = K,
                               train.set = train.set, test.set = test.set)

      BLUP_Y_test <- BLUPs_test[, focal]
      BLUP_S_test <- BLUPs_test[, setdiff(colnames(BLUPs_test), focal)]
      Ktt <- K[test.set, test.set]
      Kto <- K[test.set, train.set]
      Koo <- K[train.set, train.set]
      Vc <- kronecker(Vg.subset[F.select, F.select], solve(Ktt)) + kronecker(Ve.subset[F.select, F.select] / n.rep, diag(dim(Ktt)[1]))

      # Final CV2 test set focal trait BLUP calculation following two-step approach (Runcie & Cheng, 2019):
      focalBLUP_test <- as.numeric(matrix(BLUP_Y_test) + kronecker(t(as.matrix(Vg.subset[F.select, focal])), solve(Ktt)) %*%
        solve(Vc) %*% (matrix(as.matrix(dm.subset[test.set, F.select])) - matrix(BLUP_S_test)))

      names(focalBLUP_test) <- test.set
    } else if (CV2.method == "Bader") {
      # Final CV2 test set focal trait BLUP calculation following one-step approach (bader):
      V1.tl <- kronecker(Vg.subset[F.select, F.select], K[c(test.set, train.set), c(test.set, train.set)])
      V1.tr <- kronecker(matrix(Vg.subset[F.select, focal]), K[c(test.set, train.set), train.set])
      V1.bl <- t(V1.tr)
      V1.br <- Vg.subset[focal, focal] * K[train.set, train.set]

      V1 <- cbind(rbind(V1.tl, V1.bl), rbind(V1.tr, V1.br))

      zero <- matrix(0, nrow = length(test.set), ncol = length(train.set))

      V2.tl <- kronecker(Ve.subset[F.select, F.select] / n.rep, diag(dim(K)[1]))
      V2.tr <- kronecker(matrix(Ve.subset[F.select, focal]) / n.rep, rbind(zero, diag(length(train.set))))
      V2.bl <- t(V2.tr)
      V2.br <- Ve.subset[focal, focal] / n.rep * diag(length(train.set))

      V2 <- cbind(rbind(V2.tl, V2.bl), rbind(V2.tr, V2.br))

      V <- V1 + V2

      focalBLUP_test <- as.numeric(cbind(kronecker(t(matrix(Vg.subset[F.select, focal])), K[test.set, c(test.set, train.set)]),
                              Vg.subset[focal, focal] * K[test.set, train.set]) %*%
        solve(V) %*% rbind(matrix(as.matrix(dm.subset[c(test.set, train.set), F.select])),
                           as.matrix(dm.subset[train.set, focal])))

      names(focalBLUP_test) <- test.set
    } else if (CV2.method == "RuncieFast") {
      # Calculating BLUPs for the training set:
      BLUPs_train <- fast_o_gBLUP(Y = as.matrix(dm.subset[train.set, -1]),
                                  K = K,
                                  Vg = Vg.subset,
                                  Ve = Ve.subset / n.rep,
                                  train.set = train.set,
                                  targetName = focal)

      # Calculating all BLUPs for the test set:
      BLUPs_test <- train2test(BLUPs_train$all_gBLUPs, K = K,
                               train.set = train.set, test.set = test.set)

      BLUP_Y_test <- BLUPs_test[, focal]
      BLUP_S_test <- BLUPs_test[, setdiff(colnames(BLUPs_test), focal)]
      Ktt <- K[test.set, test.set]
      Kto <- K[test.set, train.set]
      Koo <- K[train.set, train.set]
      Vc <- kronecker(Vg.subset[F.select, F.select], solve(Ktt)) + kronecker(Ve.subset[F.select, F.select] / n.rep, diag(dim(Ktt)[1]))

      Y <- as.matrix(dm.subset[test.set, F.select])
      p <- ncol(Y)
      C <- solve(Vg.subset)
      D <- solve(Ve.subset / n.rep)
      R <- K[test.set, test.set]
      w <- eigen(R)
      Lambda.R <- diag(w$values)
      U <- w$vectors
      D.sqrt.inv <- MatrixRoot(solve(D[F.select, F.select]))
      w <- eigen(D.sqrt.inv %*% C[F.select, F.select] %*% D.sqrt.inv)
      Q.1 <- w$vectors
      Lambda.1 <- w$values
      S.1 <- vec.inv.diag(x = Lambda.1, y = diag(Lambda.R)) * (t(U) %*% (Y - BLUP_S_test) %*% MatrixRoot(D[F.select, F.select]) %*% Q.1)
      MU <- matrix(kronecker(D.sqrt.inv %*% Q.1, U) %*% matrix(S.1), ncol = p)

      matrix(BLUP_Y_test) + part2


      # Final CV2 test set focal trait BLUP calculation following two-step approach (Runcie & Cheng, 2019):
      focalBLUP_test <- as.numeric(matrix(BLUP_Y_test) + kronecker(t(as.matrix(Vg.subset[F.select, focal])), solve(Ktt)) %*%
                                     solve(Vc) %*% (matrix(as.matrix(dm.subset[test.set, F.select])) - matrix(BLUP_S_test)))

      names(focalBLUP_test) <- test.set
    }
  }

  return(list(preds = focalBLUP_test,
              regPen = OPT$optPen,
              F.subset = F.select,
              FM.loadings = fito$Loadings,
              FM.uniquenesses = fito$Uniqueness,
              FM.m = mf.max,
              FM.scores = dm,
              KMO = KMO,
              Vg = Vg,
              Ve = Ve,
              H2s = H2vec,
              AM.direct = as.numeric(temp$criterion),
              AM.indirect = temp$zxc.scores))

}

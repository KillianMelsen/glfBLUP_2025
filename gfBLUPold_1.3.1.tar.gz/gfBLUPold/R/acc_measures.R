#' acc_measures
#'
#' Calculates the accuracy measures for all proper subsets given a number of factors
#' as well as the accuracy criterion given the focal trait heritability and genetic
#' variance.
#'
#' @param factors Character vector containing the names of the factors.
#' @param Vg A genetic covariance matrix including the factors and the focal trait.
#' @param Ve A residual covariance matrix including the factors and the focal trait.
#' @param focal Name of the focal trait.
#' @param H2.focal Heritability of the focal trait.
#'
#' @return A list containing the factor subsets, the accuracy measures, and the
#' accuracy criterion.
#'
#' @keywords internal
acc_measures <- function(factors, Vg, Ve, focal, H2.focal) {

  # Obtaining all possible subsets of factors:
  zxc <- allSubsets(factors)

  # Preparing vector to store subset scores:
  zxc.score <- rep(0, length(zxc))

  # Calculating scores for all subsets:
  for (m in 1:length(zxc)) {
    zxc.names <- zxc[[m]]
    Sigma_S <- as.matrix(Vg[zxc.names, zxc.names]) + as.matrix(Ve[zxc.names, zxc.names])
    Sigma_G_YS <- as.matrix(Vg[zxc.names, focal])
    zxc.score[m] <- as.numeric(t(Sigma_G_YS) %*% solve(Sigma_S) %*% Sigma_G_YS)
  }

  # Calculating criterion:
  criterion <- H2.focal * Vg[ncol(Vg), ncol(Vg)]

  return(list(zxc = zxc, zxc.scores = zxc.score,
              criterion = criterion))
}
